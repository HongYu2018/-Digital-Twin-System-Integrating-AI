from pathlib import Path
import json,re,sys,hashlib,csv,collections
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from aihc.core import prepare_chunks,write_json,write_lines,digest
from question_spec import SPECS
manifest=json.loads((ROOT/'source_metadata/manifest.json').read_text(encoding='utf-8'))
cfg={'backend':'ollama','generation_model':'qwen2.5:7b','embedding_model':'nomic-embed-text','ollama_url':'http://localhost:11434','chunk_words':250,'chunk_overlap':40,'top_k':5,'graph_weight':0.2,'context_words':1600,'memory_k':3,'temperature':0,'num_ctx':8192,'num_predict':1024,'repeats':1,'seed':42,'timeout_seconds':600,'embedding_document_prefix':'search_document: ','embedding_query_prefix':'search_query: ','dataset_status':'AI_DRAFT_REQUIRES_EXPERT_REVIEW','benchmark_require_freeze':True,'retrieval_label_scope':'minimum_covering_spans_not_exhaustive_relevance'}
write_json(ROOT/'configs/aaib_dev.json',cfg);write_json(ROOT/'configs/aaib_evaluation.json',{**cfg,'repeats':1})
# Shared source reports in cross-report tasks must share the resampling group.
groups={'aaib-002':'pair-002-008','aaib-008':'pair-002-008','aaib-007':'pair-007-014','aaib-014':'pair-007-014'}
docs=[];page_maps={}
for m in manifest:
 raw=(ROOT/m['text_path']).read_text(encoding='utf-8');pages=raw.split('\f');parts=[];maps=[];offset=0
 for pnum,page in enumerate(pages,1):
  lines=[line for line in page.splitlines() if not re.match(r'^\s*(AAIB Bulletin:|© Crown copyright)',line)]
  clean=' '.join(' '.join(lines).split())
  if not clean:continue
  maps.append({'pdf_page':pnum,'char_start':offset,'char_end':offset+len(clean)})
  parts.append(clean);offset+=len(clean)+1
 text=' '.join(parts)
 m['group']=groups.get(m['id'],m['id'])
 docs.append({**m,'text':text,'text_sha256':hashlib.sha256(text.encode()).hexdigest(),'licence':'Contains public sector information licensed under the Open Government Licence v3.0; third-party material excluded from that licence.'})
 page_maps[m['id']]=maps
chunks=prepare_chunks(docs,cfg);bydoc={d['id']:d for d in docs};bychunks=collections.defaultdict(list)
for c in chunks:bychunks[c['doc_id']].append(c)
wordspans={d['id']:list(re.finditer(r'\S+',d['text'])) for d in docs}
missing=[]
def support(rid,anchor):
 text=bydoc[rid]['text'];pos=text.rfind(anchor)
 if pos<0:
  missing.append((rid,anchor));return None
 start=text.rfind('. ',0,pos)+2
 if start==1:start=0
 for marker in [' Synopsis ', ' Conclusion ']:
  boundary=text.rfind(marker,0,pos)
  if boundary>=start:start=boundary+len(marker)
 end=text.find('. ',pos+len(anchor)-1)
 end=end+1 if end>=0 else len(text)
 quote=text[start:end]
 # Word intervals must match the frozen pipeline chunking exactly.
 spans=wordspans[rid];a=next(i for i,w in enumerate(spans) if w.end()>start);b=next((i for i,w in enumerate(spans) if w.start()>=end),len(spans))
 candidates=bychunks[rid];cover=[];cursor=a
 while cursor<b:
  options=[c for c in candidates if c['word_start']<=cursor<c['word_start']+len(c['text'].split())]
  c=max(options,key=lambda c:c['word_start']+len(c['text'].split()))
  cover.append(c['id']);cursor=c['word_start']+len(c['text'].split())
 return {'report_id':rid,'source_url':bydoc[rid]['source_url'],'pdf_url':bydoc[rid]['pdf_url'],'pdf_pages':[p['pdf_page'] for p in page_maps[rid] if p['char_start']<end and p['char_end']>start],'quote':quote,'char_start':start,'char_end':end,'evidence_ids':cover}
qs=[];counts=collections.Counter()
for spec in SPECS:
 rid=spec['report'];counts[rid]+=1;sup=[support(rid,a) for a in spec['anchors']];sup=[x for x in sup if x]
 qs.append({'id':f"{rid}-q{counts[rid]:02d}",'split':bydoc[rid]['split'],'group':bydoc[rid]['group'],'task':spec['task'],'question':spec['question'],'answerable':True,'gold_claims':spec['gold_claims'],'reference_answer':' '.join(spec['gold_claims']),'evidence_ids':sorted({cid for s in sup for cid in s['evidence_ids']}),'source_support':sup,'annotation_status':'AI_AUTHORED_SOURCE_CHECKED_EXPERT_REVIEW_PENDING','reference_notes':'Minimum covering evidence IDs, not exhaustive passage-relevance judgments.'})
# Unanswerable questions request a definitive explanation explicitly not established by the source.
negative=[(2,'What exact route did the water take from the main cargo deck floor to GCUs 1 and 4 on G-ONEE?','The exact route was not determined.','The investigation was unable to determine the exact path that water took'),(7,'Which specific fuel-system maintenance operation was conclusively established as the cause of G-TOMX\'s power loss?','The cause was not determined; a maintenance association was only possible.','The cause of the power loss could not be determined'),(8,'At precisely which location did ice form to jam the aileron controls on G-DHLS?','The location where ice formed could not be identified.','it was not possible to identify the source of any water/fluid'),(9,'What was the definitive initiating cause of the failed G-CIMU tail-rotor duplex bearing?','The initiating cause could not be determined because the bearing was too damaged.','Despite a full forensic assessment, the bearing was too badly damaged'),(12,'Which confirmed technical engine defect prevented G-CIMC from climbing normally?','No confirmed technical issue limiting engine performance was identified.','The engineering investigation did not find evidence of any technical issue'),(17,'Which single component was conclusively proven to initiate the G-LMRC power loss?','The initiating cause was not established; the failed 1PA contactor was contributory rather than causal.','This meant that it could not supply backup power')]
for i,q,ref,anchor in negative:
 rid=f'aaib-{i:03d}';sup=support(rid,anchor)
 qs.append({'id':rid+'-u01','split':bydoc[rid]['split'],'group':bydoc[rid]['group'],'task':'unanswerable','question':q,'answerable':False,'gold_claims':[],'reference_answer':ref,'evidence_ids':[],'source_support':([sup] if sup else []) + ([support(rid,'Although the cause of the loss of the emergency electrical network on G-LMRC could not be determined')] if i==17 else []),'annotation_status':'AI_AUTHORED_SOURCE_CHECKED_EXPERT_REVIEW_PENDING','reference_notes':'Unanswerable as requested; an explicit uncertainty statement is the correct response. Source support documents the negative answer, but is excluded from retrieval-recall labels.'})
cross=[('cross-001',['aaib-002','aaib-008'],'Compare what remained unknown about water and ice in G-ONEE and G-DHLS. Do the reports establish the exact physical route or location in both cases?',['For G-ONEE the exact path of water from the cargo deck to the GCUs was not determined.','For G-DHLS neither the fluid source nor where ice formed was identified.'],['The investigation was unable to determine the exact path that water took','it was not possible to identify the source of any water/fluid']),('cross-002',['aaib-007','aaib-014'],'Compare the strength of the evidence for the engine power-loss causes in G-TOMX and N4698W.',['For G-TOMX the cause was undetermined and a maintenance association was only possible.','For N4698W the power loss was attributed to water entering the carburettor float bowl and main nozzle.'],['The cause of the power loss could not be determined','The engine’s rough running and loss of power was caused by ingestion of water'])]
for qid,rids,q,claims,anchors in cross:
 sup=[support(rid,a) for rid,a in zip(rids,anchors)];sup=[x for x in sup if x]
 qs.append({'id':qid,'split':'test','group':bydoc[rids[0]]['group'],'task':'cross_report','question':q,'answerable':True,'gold_claims':claims,'reference_answer':' '.join(claims),'evidence_ids':sorted({cid for s in sup for cid in s['evidence_ids']}),'source_support':sup,'annotation_status':'AI_AUTHORED_SOURCE_CHECKED_EXPERT_REVIEW_PENDING','reference_notes':'Reports merged into one split/resampling group to avoid pseudo-independence.'})
if missing:
 for x in missing:print('MISSING',x)
 raise SystemExit(f'{len(missing)} anchors require correction')
# Case identity is part of the question, not silently supplied from gold metadata.
write_lines(ROOT/'data/aaib/corpus.jsonl',docs);write_lines(ROOT/'data/aaib/questions.jsonl',qs)
write_lines(ROOT/'data/aaib/chunks_manifest.jsonl',[{k:v for k,v in c.items() if k!='text'} for c in chunks])
write_json(ROOT/'data/aaib/page_offsets.json',page_maps)
write_json(ROOT/'source_metadata/manifest.json',manifest)
print('SUCCESS',len(docs),'reports',len(chunks),'chunks',len(qs),'questions',dict(collections.Counter(q['split'] for q in qs)))
