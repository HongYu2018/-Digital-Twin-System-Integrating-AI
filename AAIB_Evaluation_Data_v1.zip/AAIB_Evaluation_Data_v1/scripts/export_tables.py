"""Export adjudicated score JSON as manuscript-table CSV files; never supplies ratings."""
import argparse,csv,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--scores',required=True);p.add_argument('--out',required=True);a=p.parse_args()
r=json.loads(Path(a.scores).read_text(encoding='utf-8'));out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
rows=[]
for name,c in r['conditions'].items():
 rows.append({'condition':name,'runs':c['runs'],**{'macro_'+k:v for k,v in c['macro_answerable'].items()},**{'micro_'+k:v for k,v in c['micro_answerable'].items()},'abstention_accuracy':c['abstention_accuracy_unanswerable'],'failures':c['failures'],'runs_with_invalid_citation_ids':c['runs_with_invalid_citations'],'median_pipeline_seconds':c['median_pipeline_seconds']})
with (out/'answer_quality.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
rows=[{'contrast':name,'mean_question_f1_difference':c['mean_question_f1_difference'],'incident_clusters':c['incident_clusters'],'ci_low':c['percentile_95_ci'][0] if c['percentile_95_ci'] else None,'ci_high':c['percentile_95_ci'][1] if c['percentile_95_ci'] else None} for name,c in r['paired_comparisons'].items()]
with (out/'paired_comparisons.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(out/'STATUS.txt').write_text(f"Source run status: {r['run_status']}\nRetrieval labels: {r.get('retrieval_label_scope')}\nThese tables contain supplied human ratings. They do not establish significance, operational validity or human-centred benefit. Retrieval metrics are excluded because reference passage labels are not exhaustive.\n",encoding='utf-8')
print('Saved',out)
