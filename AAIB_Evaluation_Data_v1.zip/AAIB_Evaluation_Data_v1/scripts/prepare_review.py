"""Generate draft memory and source-review files; never marks a human approval."""
from pathlib import Path
import sys,csv,json,html
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from aihc.core import read_lines,write_lines,write_json,digest
qs=read_lines(ROOT/'data/aaib/questions.jsonl');docs=read_lines(ROOT/'data/aaib/corpus.jsonl')
memory=[
 {'id':'m-initial-001','stage':'initial','instruction':'Answer the requested incident question using the report evidence. Identify the affected system and distinguish the event sequence from subsequent safety action. Keep the answer focused on what was asked.','aliases':{},'origin_groups':['aaib-001'],'source_question_ids':['aaib-001-q01','aaib-001-q03']},
 {'id':'m-update-001','stage':'update','instruction':'When asked for a cause, distinguish a failed component from its initiating mechanism. An observed component failure does not establish why that component failed. Preserve explicit uncertainty and do not reinstate hypotheses the investigation rejected.','aliases':{},'origin_groups':['aaib-009'],'source_question_ids':['aaib-009-q01','aaib-009-q02','aaib-009-u01'],'trigger_terms':['cause','caused','initiating','failure','failed','conclusively','evidence']},
 {'id':'m-update-002','stage':'update','instruction':'Distinguish an established initiating cause from a contributory failure of a backup or protective function. Absence of recurrence after several replacements does not prove a single initiating cause; a repaired backup may mask the underlying problem. Apply this distinction only when the report evidence supports it.','aliases':{},'origin_groups':['aaib-017'],'source_question_ids':['aaib-017-q01','aaib-017-q02','aaib-017-u01'],'trigger_terms':['cause','caused','initiating','contributory','replacement','replaced','failure','failed','evidence']}
]
for m in memory:
 m.update(approved_by='AI_DRAFT_NOT_EXPERT_APPROVED',approved_at='2026-09-22',review_status='pending',provenance_note='Authored from development references before experimental runs; not an observed human interaction or learned update.')
write_lines(ROOT/'data/aaib/memory.jsonl',memory)
write_lines(ROOT/'data/aaib/corpus_dev.jsonl',[d for d in docs if d['split']=='dev'])
write_lines(ROOT/'data/aaib/questions_dev.jsonl',[q for q in qs if q['split']=='dev'])
review=ROOT/'review';review.mkdir(exist_ok=True)
for split in ['dev','test']:
 subset=[q for q in qs if q['split']==split]
 p=review/f'{split}_reference_review.csv'
 if not p.exists():
  with p.open('w',newline='',encoding='utf-8') as f:
   w=csv.DictWriter(f,fieldnames=['question_id','reviewer_id','decision','reviewed_at','notes']);w.writeheader()
   w.writerows({'question_id':q['id'],'decision':'pending'} for q in subset)
 rows=[]
 for q in subset:
  sources=''.join(f'<blockquote>{html.escape(s["quote"])}</blockquote><p><a href="{html.escape(s["pdf_url"])}#page={s["pdf_pages"][0]}">Original PDF, file page(s) {s["pdf_pages"]}</a> · {html.escape(s["report_id"])}</p>' for s in q['source_support'])
  rows.append(f'<article><h2>{q["id"]} · {q["task"]}</h2><h3>{html.escape(q["question"])}</h3><p>Answerable: {q["answerable"]} · Group: {q["group"]}</p><p>{html.escape(q["reference_answer"])}</p><ol>'+''.join('<li>'+html.escape(c)+'</li>' for c in q['gold_claims'])+'</ol>'+sources+'</article>')
 (review/f'{split}_references.html').write_text('<!doctype html><meta charset="utf-8"><title>AAIB reference review</title><style>body{font:17px system-ui;max-width:1000px;margin:40px auto;line-height:1.6;background:#f3f5f8;color:#183044}article{background:white;padding:24px;margin:25px 0}blockquote{border-left:4px solid #34718a;padding-left:18px}h1,h2{line-height:1.2}</style><h1>'+split.upper()+' reference review</h1><p>AI-authored draft. Check original PDFs, claim boundaries, completeness, answerability and source passages. Record accept/revise/exclude, your reviewer ID and date in the matching CSV. Do not use held-out reference answers to tune the system or memory. Correct JSONL references before freezing, not after examining condition scores.</p>'+''.join(rows),encoding='utf-8')
write_json(ROOT/'data/aaib/draft_snapshot.json',{'questions_hash':digest(qs),'memory_hash':digest(memory),'corpus_hash':digest(docs),'status':'DRAFT_UNREVIEWED'})
print('Created development corpus, draft CLKM and reference-review pages. No human approvals recorded.')
