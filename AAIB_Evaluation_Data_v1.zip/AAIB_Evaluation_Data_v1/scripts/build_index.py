"""Checkpointed Ollama index construction. Rerun exactly the same command to resume."""
from pathlib import Path
import sys,argparse
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from aihc.core import *
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for k in ['config','corpus','out']:p.add_argument('--'+k,required=True)
 a=p.parse_args();cfg=read_json(a.config);docs=read_lines(a.corpus);validate_config(cfg)
 chunks=prepare_chunks(docs,cfg);backend=Backend(cfg);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 prompt=(ROOT/'prompts/graph.txt').read_text(encoding='utf-8')
 identity={'config':cfg,'corpus_hash':digest(docs),'backend_identity':backend.identity,'graph_prompt':prompt,'builder_hash':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'core_hash':hashlib.sha256((ROOT/'aihc/core.py').read_bytes()).hexdigest()}
 if (out/'checkpoint_identity.json').exists():
  if read_json(out/'checkpoint_identity.json')!=identity:raise ValueError('Checkpoint inputs/model/code changed. Use a new output directory.')
 else:write_json(out/'checkpoint_identity.json',identity)
 if (out/'index.json').exists():print('Index already complete:',out/'index.json');return
 cache=out/'checkpoint';cache.mkdir(exist_ok=True)
 def log_calls():
  if backend.calls:
   with (out/'construction_calls.jsonl').open('a',encoding='utf-8') as f:
    for call in backend.calls:f.write(canonical(call)+'\n')
   backend.calls.clear()
 vectors=[]
 for start in range(0,len(chunks),16):
  path=cache/f'vectors-{start:05d}.json'
  if not path.exists():
   try:write_json(path,backend.embed([c['text'] for c in chunks[start:start+16]]))
   finally:log_calls()
  batch=read_json(path)
  if len(batch)!=len(chunks[start:start+16]):raise ValueError('Bad cached embedding batch')
  vectors.extend(batch)
  print(f'Embeddings {min(start+16,len(chunks))}/{len(chunks)}',flush=True)
 triples=[];rejected=[]
 for i,ch in enumerate(chunks):
  path=cache/f'graph-{i:05d}.json'
  if not path.exists():
   try:
    result,meta=backend.generate(prompt,ch['text'],cfg['seed'],graph=True)
    if not isinstance(result,dict) or not isinstance(result.get('triples'),list):raise ValueError('Expected a JSON object containing a triples array')
    good,bad=validate_triples(result['triples'],ch)
    write_json(path,{'chunk_id':ch['id'],'triples':good,'rejected':bad,'raw':meta.get('raw')})
   except Exception as e:
    write_json(out/'last_failure.json',{'chunk_id':ch['id'],'error':str(e),'raw':getattr(e,'raw',None)})
    raise
   finally:log_calls()
  row=read_json(path)
  if row['chunk_id']!=ch['id']:raise ValueError('Cached chunk order mismatch')
  triples.extend(row['triples']);rejected.extend(row['rejected'])
  print(f'Graph {i+1}/{len(chunks)}; accepted {len(row["triples"])}; rejected {len(row["rejected"])}',flush=True)
 index={'config':cfg,'backend_identity':backend.identity,'corpus_hash':digest(docs),'documents':[{k:v for k,v in d.items() if k!='text'} for d in docs],'chunks':chunks,'vectors':vectors,'triples':triples,'graph_prompt':prompt,'graph_reviewed':False,'graph_origin':'model_extracted'}
 index['index_hash']=digest(index);write_json(out/'index.json',index);write_lines(out/'rejected_triples.jsonl',rejected)
 with (out/'graph_audit.csv').open('w',encoding='utf-8',newline='') as f:
  fields=['edge_id','chunk_id','subject','relation','object','evidence','decision','reviewer_id','notes'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for i,t in enumerate(triples):w.writerow({**{k:t[k] for k in ['chunk_id','subject','relation','object','evidence']},'edge_id':i,'decision':'pending'})
 print(f'COMPLETE: {len(chunks)} chunks, {len(triples)} candidate edges, {len(rejected)} rejected candidates. Audit graph_audit.csv before final evaluation.')
if __name__=='__main__':main()
