"""Record completed human reviews and lock inputs before held-out evaluation."""
from pathlib import Path
import sys,argparse,csv,datetime
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from aihc.core import *
def main():
 p=argparse.ArgumentParser();p.add_argument('--index',required=True);a=p.parse_args()
 questions=read_lines(ROOT/'data/aaib/questions.jsonl');memory=read_lines(ROOT/'data/aaib/memory.jsonl')
 review=[]
 for split in ['dev','test']:
  with (ROOT/f'review/{split}_reference_review.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
  wanted={q['id'] for q in questions if q['split']==split}
  if len(rows)!=len(wanted) or {r['question_id'] for r in rows}!=wanted:raise ValueError('Reference review IDs do not match questions')
  if any(r['decision'].strip().lower()!='accept' or not r['reviewer_id'].strip() or not r['reviewed_at'].strip() for r in rows):raise ValueError(f'Complete {split} reference review; correct drafts and resolve revise/exclude decisions before freezing')
  review.extend(rows)
 for m in memory:
  if m.get('review_status')!='accepted' or not m.get('approved_by','').strip() or m['approved_by'].startswith('AI_') or not m.get('approved_at'):raise ValueError('Memory requires a real reviewer, date and review_status accepted')
 path=Path(a.index);index=read_json(path/'index.json')
 if index['corpus_hash']!=digest(read_lines(ROOT/'data/aaib/corpus.jsonl')):raise ValueError('Final index must cover the full frozen corpus')
 with (path/'graph_audit.csv').open(encoding='utf-8-sig',newline='') as f:edges=list(csv.DictReader(f))
 if len(edges)!=len(index['triples']) or {int(e['edge_id']) for e in edges}!=set(range(len(index['triples']))):raise ValueError('Graph audit edge IDs must match index')
 for e in edges:
  if e['decision'] not in ['accept','reject'] or not e['reviewer_id'].strip():raise ValueError('Complete graph audit with accept/reject and reviewer ID')
  if any(e[k]!=index['triples'][int(e['edge_id'])][k] for k in ['chunk_id','subject','relation','object','evidence']):raise ValueError('Audit edge content differs from index')
 # Preserve extracted graph; rejected edges are removed in a separate reviewed index.
 audited=path.parent/(path.name+'-reviewed');audited.mkdir(exist_ok=False)
 index.pop('index_hash');index['triples']=[index['triples'][int(e['edge_id'])] for e in edges if e['decision']=='accept'];index['graph_reviewed']=True;index['graph_audit_hash']=digest(edges);index['index_hash']=digest(index)
 validate_dataset(index,questions,memory);write_json(audited/'index.json',index)
 byreview={r['question_id']:r for r in review}
 for q in questions:
  q.update(annotation_status='HUMAN_REVIEWED',reference_reviewed_by=byreview[q['id']]['reviewer_id'],reference_reviewed_at=byreview[q['id']]['reviewed_at'])
 write_lines(ROOT/'data/aaib/questions.jsonl',questions)
 write_lines(ROOT/'data/aaib/questions_dev.jsonl',[q for q in questions if q['split']=='dev'])
 cfg=read_json(ROOT/'configs/aaib_evaluation.json');cfg['dataset_status']='HUMAN_REVIEWED_BENCHMARK_NOT_YET_SCORED';cfg['benchmark_require_freeze']=True
 lock={'questions_hash':digest(questions),'memory_hash':digest(memory),'index_hash':index['index_hash'],'config_hash':digest(cfg),'reference_reviews_hash':digest(review),'graph_reviews_hash':digest(edges),'answer_prompt_hash':hashlib.sha256((ROOT/'prompts/answer.txt').read_bytes()).hexdigest(),'core_hash':hashlib.sha256((ROOT/'aihc/core.py').read_bytes()).hexdigest(),'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 write_json(ROOT/'configs/aaib_frozen.json',cfg);write_json(ROOT/'data/aaib/freeze.json',lock);write_json(ROOT/'review/frozen_review_records.json',{'references':review,'graph':edges})
 print('Frozen. Use configs/aaib_frozen.json and index',audited)
if __name__=='__main__':main()
