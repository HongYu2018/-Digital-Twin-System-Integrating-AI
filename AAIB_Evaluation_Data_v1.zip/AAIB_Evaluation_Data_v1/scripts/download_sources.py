"""Download the frozen report PDFs and verify their recorded SHA-256 hashes."""
from pathlib import Path
import json,hashlib,argparse,urllib.request
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',default='source_pdfs');a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
for m in json.loads((ROOT/'source_metadata/manifest.json').read_text(encoding='utf-8')):
 path=out/(m['id']+'.pdf')
 if path.exists():data=path.read_bytes()
 else:
  with urllib.request.urlopen(m['pdf_url'],timeout=120) as response:data=response.read()
 if hashlib.sha256(data).hexdigest()!=m['pdf_sha256']:raise ValueError(f'Source hash changed for {m["id"]}; preserve and investigate versions, do not silently replace the frozen text.')
 path.write_bytes(data);print('Verified',path,flush=True)
