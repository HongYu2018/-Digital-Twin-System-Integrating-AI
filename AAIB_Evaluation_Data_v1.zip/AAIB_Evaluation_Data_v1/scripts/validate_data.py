"""Validate source integrity and pipeline compatibility without calling Ollama."""
from pathlib import Path
import sys,hashlib,collections
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from aihc.core import *
cfg=read_json(ROOT/'configs/aaib_dev.json');docs=read_lines(ROOT/'data/aaib/corpus.jsonl');qs=read_lines(ROOT/'data/aaib/questions.jsonl');memory=read_lines(ROOT/'data/aaib/memory.jsonl')
chunks=prepare_chunks(docs,cfg);index={'chunks':chunks};validate_config(cfg);validate_dataset(index,qs,memory)
bydoc={d['id']:d for d in docs};bychunk={c['id']:c for c in chunks}
for d in docs:
 assert hashlib.sha256(d['text'].encode()).hexdigest()==d['text_sha256'],f'Text hash differs: {d["id"]}'
for q in qs:
 assert q['source_support'],q['id']
 for s in q['source_support']:
  d=bydoc[s['report_id']];assert d['text'][s['char_start']:s['char_end']]==s['quote'],q['id']
  assert d['split']==q['split'] and d['group']==q['group'],q['id']
  assert all(cid in bychunk for cid in s['evidence_ids']),q['id']
  # Cover the exact source span, without assuming these are all relevant chunks.
  prefix=len(d['text'][:s['char_start']].split());end=len(d['text'][:s['char_end']].split())
  covered=set()
  for cid in s['evidence_ids']:
   c=bychunk[cid];assert c['doc_id']==d['id'];covered.update(range(c['word_start'],c['word_start']+len(c['text'].split())))
  assert set(range(prefix,end))<=covered,q['id']
for split in ['dev','test']:
 subset=[q for q in qs if q['split']==split]
 print(split,':',len(subset),'questions;',len({q['group'] for q in subset}),'incident clusters;',dict(collections.Counter(q['task'] for q in subset)))
result={'status':'PASS_MECHANICAL_CHECKS_NOT_EXPERT_VALIDATION','documents':len(docs),'chunks':len(chunks),'questions':len(qs),'questions_hash':digest(qs),'memory_hash':digest(memory),'corpus_hash':digest(docs),'checks':['pipeline schema','distinct dev/test incident groups','development-only memory provenance','exact reference quotes','source text hashes','reference span coverage']}
write_json(ROOT/'validation/dataset_validation.json',result)
print(f'PASS: {len(docs)} reports, {len(chunks)} chunks, {len(qs)} questions. Expert reference and graph reviews remain required.')
