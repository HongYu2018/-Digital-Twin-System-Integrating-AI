# Source attribution and reuse

Source reports: UK Air Accidents Investigation Branch (AAIB), published through GOV.UK. Report-specific titles, original report pages and PDF URLs are in `source_metadata/manifest.json` and each corpus document. Retrieved 22 September 2026. Contains public sector information licensed under the Open Government Licence v3.0, except where otherwise stated.

- GOV.UK terms: https://www.gov.uk/help/terms-conditions
- Open Government Licence v3.0: https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/
- AAIB report catalogue: https://www.gov.uk/aaib-reports

The licence does not cover third-party material, personal data, logos or other listed exclusions. Original reports retain their individual notices. Extracted text is supplied for source verification and research; PDF figures/images are not republished in this archive. Check report notices before redistributing separately attributed third-party extracts. Do not imply AAIB, GOV.UK or an aircraft manufacturer's endorsement.

Questions, reference facts, CLKM drafts and reconstructed code are new evaluation materials, not AAIB-approved annotations. No official AAIB answer benchmark or operational maintenance advice is claimed. The manuscript authors should select an appropriate licence for their final code/annotation release after resolving their institutional requirements; this package does not purport to grant rights to the transferred industrial implementation.
