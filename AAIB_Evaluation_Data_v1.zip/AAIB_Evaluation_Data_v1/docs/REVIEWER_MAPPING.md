# Relationship to the revision requests

| Concern | What this package supplies | Remaining work / honest boundary |
|---|---|---|
| C1: weak and underspecified evaluation | 18 source reports, 80 draft questions, source hashes, grouped split, exact settings/prompts, raw-output logging and protocol | Expert validate references, run models, adjudicate outputs; this is still a modest exploratory sample |
| C2: inconsistent P/R/F1 | Explicit common scoring unit, same-unit macro and micro formulas, known-count tests, complete-rating checks | Original values cannot be recalculated without original records; replace them with clearly identified reconstruction results |
| C3: missing baselines/ablations | LLM-only, vector RAG, lightweight KG-RAG, static and updated CLKM, information-matched vector-guidance control | Execute all conditions fairly; do not call the lightweight graph method a reproduction of a published GraphRAG system |
| C4: human-centred claim | Source-review and blinded expert-rating tools | They are not a user study; conduct a separate task-based study or narrow the claim |
| C5: broad practical claims | Retrospective AAIB incident-analysis benchmark | Does not validate a live operational maintenance twin |
| C6: reproducibility and missing appendix | Standalone code, configs, source metadata/text, manifests, prompt files, review forms, tests, frozen-input workflow | Release reviewed artifacts and actual outputs; include the missing manuscript appendix and explain reconstruction |
| C7: references | No changes to manuscript bibliography | Remove duplicate refs 18/29; replace or appropriately qualify vendor-blog ref 11 after checking the manuscript |
| C8: presentation | Consistent CLKM terminology in the new package | Proofread the manuscript, align system description with actual reconstruction, remove overstated conclusions |

Report results whether positive, null or negative. If CLKM provides no measurable gain, that finding constrains the claims rather than invalidating the entire systems contribution. Do not describe author-written guidance as learned corporate memory or a verified record of expert interactions.

The revision invitation is not a guarantee of acceptance. This package is evidence preparation, not a promise that the editor's concerns have already been resolved.
