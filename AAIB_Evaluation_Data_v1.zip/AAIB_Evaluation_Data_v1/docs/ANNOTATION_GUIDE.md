# Human annotation guide

## Reference validation comes first

Open the development or test reference page in `review/`. Each card has the question, answerability, proposed reference facts, exact extracted support and links to original PDF file pages. Check:

1. The case identity, dates, numerical values and aircraft/system names.
2. Whether each reference fact is entailed, including words such as possible, likely, contributory, planned and completed.
3. Whether the proposed answer actually addresses the question and includes all required facts.
4. Whether reference units are sufficiently atomic and consistent across questions. Split compound units before freezing if partial answers should earn partial credit.
5. Whether unanswerable questions request a fact the report explicitly leaves unresolved. They should not reward invented certainty.
6. Whether the reference spans cover the stated facts, and whether alternate supporting passages exist.

Record `accept`, `revise` or `exclude`, actual reviewer ID, review date and notes in the corresponding reference-review CSV. Make corrections before marking accept; retain a change log. This package has not pre-filled any human decisions. Experts may reject weak questions. Do not keep questions simply because a favored system answers them better.

Memory approval is separate: review each instruction, trigger and development source question in `data/aaib/memory.jsonl`. Check that it conveys a transferable reasoning distinction rather than an answer to a test case. Set accepted status only after a real review. If developing new updates, use development interactions only, log the expert input and approval, and freeze before test outputs exist.

Graph audit: in the index's `graph_audit.csv`, assess each subject–relation–object statement against the full source context. Exact quotation does not catch reversed cause, negation, speculation or unrelated entities. Accept or reject; do not rewrite strings in this file. A corrected extraction rule requires a new build. The freeze script preserves the original candidates and creates a separate reviewed index with rejected edges removed.

## Blinded output ratings

Enter a stable anonymous rater ID. For each output, read the question, required reference facts, model answer, source passages and cited evidence. Keep the condition mapping private. Assess semantic equivalence, not exact wording.

- TP: number of distinct required reference facts correctly expressed. A fact loses credit if its certainty is overstated or its attribution is wrong.
- FN: required facts not correctly expressed. Always TP + FN = the reference fact count.
- FP: distinct incorrect or unsupported factual assertions. Do not count a duplicate paraphrase again. A supported extra detail is not an FP, but does not earn additional TP.
- Appropriate abstention: 1 only when an unanswerable-as-requested question is appropriately answered with the report's uncertainty; otherwise 0. For answerable items select 0. On unanswerable items TP=FN=0; still count invented assertions as FP.
- Notes: map model statements to reference fact numbers; record errors, extra irrelevant detail, citation problems and difficult judgments. Do not silently change gold references after seeing condition performance.

For example, if the report says a failure was *possible*, an answer declaring that failure the proven cause is not a correct match. If a question asks for two independent facts and the answer correctly supplies one while inventing another, TP=1, FN=1 and FP=1.

A valid citation ID is not enough. Open its passage and check whether it supports the attached claim. The current scorer tracks unknown IDs but does not quantify entailment or completeness. A separate claim–citation review is needed before making citation-faithfulness claims.

A failed generation receives TP=0 and FN equal to all required facts, with abstention=0. Empty text is not a successful abstention. Keep failures in the scored set.

Download the CSV before closing or moving the HTML. Browser autosave is a convenience, not the research record. Independent raters must submit separate files; agree an adjudicated complete CSV for the scoring command. Do not average TP/FP/FN counts into fractional values or delete disagreements. Report who rated what, the agreement analysis, and adjudication decisions.

## Human-centred evaluation is a separate task

Reference annotation and model-output grading do not measure a person's benefit from using the system. To support that claim, obtain appropriate institutional review/consent for a small expert task study and predefine outcomes such as task correctness, time, evidence-checking effort and perceived usefulness. Use counterbalanced conditions and novel tasks. Otherwise describe the system as designed for human oversight and limit benefit claims. No participant data or study results are included here.
