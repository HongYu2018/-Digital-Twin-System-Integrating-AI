# Evaluation protocol and limitations

## Scope and selection

Research question: for retrospective questions about published aviation investigations, does this reconstructed system improve source-supported answer quality compared with retrieval baselines, and what is attributable to graph retrieval or development-derived guidance?

The collection was selected on 22 September 2026 from the first 50 results of the GOV.UK search API, `filter_format=aaib_report&count=50&order=-public_timestamp`. All 18 entries labeled `field-investigation` were included. The initial fetch script allowed up to 24 eligible reports; only 18 occurred in this 50-entry snapshot. Selection did not use model scores. The saved search snapshot and 50-entry selection log fix the sampling frame; no claim of a random or representative AAIB sample is made. The rule favors recent, longer investigations. Technical, human-factor and unresolved-cause cases are present.

Authoritative catalogue: https://www.gov.uk/aaib-reports
Search API: https://www.gov.uk/api/search.json?filter_format=aaib_report&count=50&order=-public_timestamp

Each report has official content-API metadata, report and attachment URLs, retrieval date and PDF SHA-256. Text was extracted using `pdftotext -layout`; repeated AAIB headers and Crown copyright footer lines were removed and whitespace normalized. PDF file-page offsets and normalized text hashes are retained. Figures, tables and PDF layouts are not reconstructed faithfully by this text representation. Review questions against original PDFs; inspect OCR/extraction if a passage looks ambiguous. Questions were chosen from explicit textual findings and actions, not unsupported inference from figures. Public reports can be revised; hashes identify the downloaded version.

## Split and reference construction

Reports in catalogue order were numbered 001–018. Reports 001, 005, 009, 013 and 017 form development (every fourth report starting with the first); the other 13 form test. Two cross-report tasks link 002/008 and 007/014, so each pair is one resampling cluster. There are 5 development and 11 test clusters.

There are four base questions per report, six additional unanswerable-as-requested questions and two cross-report questions: 80 in total (22 development, 58 test). Test has 54 answerable and 4 unanswerable questions. Some questions intentionally probe the same finding with different requests; they are correlated. Broad task counts and hashes are emitted by `validate_data.py`.

Questions, reference facts and source spans are AI-authored drafts, subsequently checked against extracted sources, without experimental answer outputs. They require independent domain review. The dataset constructor has seen test sources: this is not a blind external benchmark. Test reports must be held out from memory creation, prompt/parameter tuning and model-output-driven question selection. Preserve construction provenance and disclose who authored, reviewed and tuned each component.

**The report matching a query is intentionally present in the retrieval corpus.** The target is evidence retrieval and source-grounded answering, not prediction of an unseen accident. Gold claims, reference answers, labels and support annotations are never supplied to the answer model. The query itself identifies the incident. All retrieval conditions use the same corpus and embedding settings; the LLM-only control gets no source text. Public pretraining exposure cannot be ruled out, even for recent documents.

## Six conditions

| Condition | Retrieval | Guidance |
|---|---|---|
| llm_only | None | None |
| vector_rag | Cosine top-5 | None |
| kg_rag | Vector retrieval plus one-hop shared-entity graph reranking | None |
| clkm_static | Same graph retrieval | Initial memory only |
| clkm_updated | Same graph retrieval | Initial plus development-derived updates |
| vector_notes | Vector retrieval | The identical selected guidance supplied to clkm_updated |

This is a lightweight KG-RAG implementation, not a reproduction of Microsoft's GraphRAG. Do not label its scores as a published GraphRAG algorithm benchmark. Graph extraction produces up to four relationships per chunk using the fixed graph prompt and five allowed relation types. Subject, object and evidence must occur verbatim; unsuccessful candidates are logged. Exact entity-string overlap drives one-hop retrieval. There is no formal causal inference, graph embedding, community summarization or learned reranker. Human graph review is necessary, especially for uncertain or negated causal language. Report the number of accepted/rejected edges and how often reranking actually changes the evidence.

Draft CLKM is one initial instruction plus two curated updates based only on development cases G-CIMU and G-LMRC. Update selection uses declared lexical triggers followed by embedding similarity. At most three entries are selected. All current alias maps are empty: the experiment does **not** test terminology expansion. Static/updated graph retrieval can therefore be identical; differences may arise from answer guidance. The vector-notes condition controls for that guidance. These ablations evaluate a frozen initial-versus-updated memory contrast, **not** observed continuous learning, expert collaboration quality or a longitudinal organizational-memory deployment. Genuine expert-generated updates can replace the drafts before freezing if their development-only provenance is logged.

## Fixed implementation settings

- Ollama `qwen2.5:7b` generation and `nomic-embed-text` embeddings; exact digests and Ollama version recorded on the user's computer.
- Nomic inputs use `search_document: ` for source and memory documents; `search_query: ` for retrieval questions. This follows the model card: https://huggingface.co/nomic-ai/nomic-embed-text-v1.5
- 250 whitespace words per chunk; overlap 40; cosine similarity; top_k 5; graph weight 0.2.
- Shared evidence-plus-memory budget 1,600 whitespace words, not tokens. Prompt overhead is additional. Context 8,192 model tokens; output cap 1,024; truncation/error behavior logged. The same cap is applied to every grounded condition, with memory consuming part of it.
- Temperature 0; development and default test each use one repeat with seed 42. This efficient primary study does not estimate run-to-run variability. An optional three-repeat study (seeds 42, 43, 44) must be declared before freezing. A fixed shuffled job order reduces systematic order effects. Exact repeat independence is not assumed.
- No training or fine-tuning. No external closed-model judge. Identical answer-generation model and prompt across conditions.
- The full final corpus contains 18 reports; a development-only index is supplied for low-cost debugging. Recheck development performance on the full corpus before freezing if changing corpus scope could affect tuning decisions. Do not inspect test outputs for tuning.

## Scoring and uncertainty

Primary endpoint: answerable-question macro F1, paired updated CLKM minus vector RAG. This is a proposed pre-analysis choice; record acceptance before final runs. Key secondary contrasts: updated-minus-static CLKM, KG-minus-vector, static-minus-KG, updated-minus-vector-notes, full-minus-LLM. Report all contrasts, including null/negative findings. Secondary intervals are exploratory and not multiple-comparison-adjusted claims of significance.

The scoring unit is an adjudicated reference fact. TP is a correctly expressed required fact, FN a missing required fact, FP an incorrect or unsupported factual assertion. Each reference fact can be matched once; duplicate paraphrases receive no extra credit. Compound reference facts require all specified components or must be split into atomic units before freezing. Correct additional supported details are not FP, but receive no TP if outside the required answer. This task-specific fact scoring does not equal exhaustive extraction of every report fact. Annotate irrelevant verbosity separately.

Per answer: P=TP/(TP+FP), R=TP/(TP+FN), F1=2TP/(2TP+FP+FN), zero on empty denominator. Macro averages use the same answerable units; micro aggregates the same TP/FP/FN. The metrics cannot produce an average F1 above both average precision and recall under this protocol. Repeats are averaged within question for paired contrasts. A 2,000-draw paired cluster bootstrap resamples incident groups and preserves all questions and repeats within the selected group. With only 11 test clusters, intervals are unstable/exploratory; 348 default responses (or 1,044 with three repeats) are not independent observations. No retrospective power or broad superiority claim is justified.

Unanswerable questions are scored separately for appropriate uncertainty/abstention. A clear statement that the report did not establish the requested fact is correct; a blanket refusal is insufficient if it ignores the answerable uncertainty distinction. Four test negatives are too few to establish general refusal robustness. Do not describe these as out-of-corpus questions: their negative findings are in the corpus.

Failures are retained and receive no correct-fact or abstention credit. Report model and parse failures separately from fluent factual errors. Unknown citation IDs are checked mechanically; valid IDs do not prove citation support. Human assessors must judge whether each cited passage entails the assertion. The package does not automatically produce a citation-entailment score or a user-study outcome.

At least two independent raters on all outputs, or a prespecified stratified subset plus adjudication, would strengthen credibility. Report qualifications, training, overlap, disagreements and agreement method; never claim this took place merely because an HTML interface is provided. System identities are hidden from raters, but source availability can reveal the condition. The public test source references remain visible for factual assessment.

## Retrieval metrics require more annotation

`evidence_ids` currently identify minimal chunk sets covering selected reference spans. They are **not exhaustive relevance judgments**: the same fact may occur in the synopsis and conclusion, or in overlapping chunks. The inherited raw retrieval precision/recall/nDCG fields are therefore diagnostic matches to these reference IDs, not defensible estimates of comprehensive retrieval quality. The table exporter deliberately omits them. Do not put those numbers in the paper as retrieval gains.

To claim retrieval-quality improvement, pool retrieved passages across all conditions before blinded relevance labeling, include alternative supporting passages identified from the full reports, specify a graded/binary relevance definition, freeze the pooled judgments, and recompute metrics on that set. Report pooled-label coverage and residual incompleteness. This annotation and recomputation are additional work; they have not been performed in the package. Alternatively narrow the claims to human-scored answer quality.

## Efficiency and reproducibility

Record model digests, hardware, OS, Python/Ollama versions, warm-up and repeated-run policy. Median `pipeline_seconds` includes per-job retrieval/generation but excludes initial shared query/memory embedding precomputation and index construction. It is not user task-completion time. Construction call logs capture per-call model timings; report cold-start/cache effects and embedding/index costs separately. No GPU utilization or energy measurements are supplied.

Reference, memory and graph review records plus frozen hashes make inputs reviewable. Raw responses, evidence, selected memory, prompts, seeds, failures and generation token counters are saved. The original industrial code and records are unavailable: this evaluation supplies evidence about the reconstruction only. The original numeric table cannot be recovered from this benchmark and must not be relabeled as if it were.

## Claims this study cannot establish

No operational maintenance twin, live synchronization, real-time industrial decision safety, field deployment effectiveness, general aerospace representativeness, or continuous memory evolution is evaluated. Human-centred benefit requires a separate task-based expert/user study; source annotation alone establishes reference quality. Noise resistance needs a prespecified perturbation experiment; the mere presence of multiple reports is not such an experiment. Traceable sources support auditability, not proof of interpretability or calibrated trust. Report these boundaries and any lack of measurable gain explicitly.
