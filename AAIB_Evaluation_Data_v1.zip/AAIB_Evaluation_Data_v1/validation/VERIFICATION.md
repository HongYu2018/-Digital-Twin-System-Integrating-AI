# Verification record — 22 September 2026

- 18 corpus records; 505 deterministic chunks; 80 questions (22 development / 58 test).
- Mechanical validation passed: reference quotes match source offsets, cited chunk spans cover those quotes, normalized-text hashes match, source/question incident groups agree, dev/test groups are separate, memory provenance is development-only.
- 14 Python unit/integration tests passed in the hosted Linux/Python 3.12 environment. Tests cover metric counts, macro-F1 consistency, complete scoring, leakage rejection, graph grounding, retrieval values, budget/memory behavior, Ollama API mocks and invalid JSON, embedding prefixes, AAIB provenance, and checkpoint reuse.
- Full source-reference inspection corrected a repeated recommendation anchor so G-ONEE question 04 points specifically to Recommendation 2026-013, not the similarly worded 2026-015.
- No actual Ollama model generation, Windows execution, independent aviation-expert review, graph extraction audit, participant study or experimental performance measurement was performed in this environment.
- No publication metrics are included. The provided human review CSVs remain pending and CLKM entries remain explicitly AI drafts.

Run validation and tests on the user's Windows computer before starting the development pilot. Test success demonstrates implementation checks, not scientific validity of the hypotheses.
