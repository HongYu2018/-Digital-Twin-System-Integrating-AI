"""Small, inspectable evaluation runner. Standard library only (pypdf for PDF import)."""
import argparse
import collections
import csv
import hashlib
import html
import json
import math
import os
from pathlib import Path
import platform
import random
import re
import statistics
import sys
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
CONDITIONS = ['llm_only', 'vector_rag', 'kg_rag', 'clkm_static', 'clkm_updated', 'vector_notes']

class ModelOutputError(ValueError):
    def __init__(self, message, raw):
        super().__init__(message)
        self.raw = raw

def canonical(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':'))

def digest(x):
    return hashlib.sha256(canonical(x).encode()).hexdigest()

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def read_lines(path):
    return [json.loads(s) for s in Path(path).read_text(encoding='utf-8').splitlines() if s.strip()]

def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def write_lines(path, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(''.join(canonical(r) + '\n' for r in rows), encoding='utf-8')

def tokens(text):
    return re.findall(r'[\w-]+', text.lower())

def cosine(a, b):
    if len(a) != len(b):
        raise ValueError('Embedding dimension mismatch')
    den = math.sqrt(sum(v*v for v in a) * sum(v*v for v in b))
    return sum(x*y for x, y in zip(a, b)) / den if den else 0.0

def demo_embed(text):
    # Hashing bag-of-words: deterministic mechanics test, NOT a semantic embedding.
    v = [0.0] * 256
    for t in tokens(text):
        v[int(hashlib.sha256(t.encode()).hexdigest()[:8], 16) % len(v)] += 1
    return v

class Backend:
    def __init__(self, config):
        self.c = config
        self.calls = []
        self.identity = {'backend': config['backend']}
        if config['backend'] == 'ollama':
            self.identity['version'] = self.http('/api/version')
            tags = self.http('/api/tags')['models']
            for role in ['generation_model', 'embedding_model']:
                wanted = config[role]
                match = [m for m in tags if m.get('name') in (wanted, wanted + ':latest')]
                if not match:
                    raise ValueError(f'Model {wanted} is not installed; pull it and rerun.')
                self.identity[role] = {'name': match[0]['name'], 'digest': match[0]['digest']}
        elif config['backend'] != 'demo':
            raise ValueError('backend must be demo or ollama')

    def http(self, endpoint, payload=None):
        data = None if payload is None else json.dumps(payload).encode()
        req = urllib.request.Request(self.c['ollama_url'].rstrip('/') + endpoint,
                                     data=data, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=self.c.get('timeout_seconds', 300)) as response:
            return json.load(response)

    def embed(self, texts, role="document"):
        if self.c['backend'] == 'demo':
            return [demo_embed(t) for t in texts]
        out = []
        prefix = self.c.get('embedding_query_prefix' if role == 'query' else 'embedding_document_prefix', '')
        texts = [prefix + text for text in texts]
        for start in range(0, len(texts), 16):
            t = time.perf_counter()
            response = self.http('/api/embed', {'model': self.c['embedding_model'],
                                 'input': texts[start:start+16], 'truncate': False})
            vectors = response['embeddings']
            if len(vectors) != len(texts[start:start+16]):
                raise ValueError('Embedding response count mismatch')
            out.extend(vectors)
            self.calls.append({'kind': 'embed', 'seconds': time.perf_counter()-t,
                               'prompt_eval_count': response.get('prompt_eval_count')})
        return out

    def generate(self, system, user, seed, graph=False):
        started = time.perf_counter()
        if self.c['backend'] == 'demo':
            if graph:
                result = {'triples': []}
            else:
                # Copying evidence is intentionally not a research answer generator.
                payload = json.loads(user)
                chunks = payload['evidence']
                result = {'answer': 'DEMONSTRATION ONLY. ' + (chunks[0]['text'] if chunks else 'No supplied evidence.'),
                          'citations': [chunks[0]['id']] if chunks else []}
            return result, {'seconds': time.perf_counter()-started, 'input_tokens': None,
                            'output_tokens': None, 'raw': canonical(result)}
        response = self.http('/api/chat', {
            'model': self.c['generation_model'], 'stream': False, 'format': 'json',
            'messages': [{'role': 'system', 'content': system}, {'role': 'user', 'content': user}],
            'options': {'temperature': self.c['temperature'], 'seed': seed,
                        'num_ctx': self.c['num_ctx'], 'num_predict': self.c['num_predict']}})
        raw = response['message']['content']
        meta = {'seconds': time.perf_counter()-started, 'input_tokens': response.get('prompt_eval_count'),
                'output_tokens': response.get('eval_count'), 'raw': raw}
        self.calls.append({'kind': 'graph' if graph else 'answer', **meta})
        try:
            result = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ModelOutputError('Invalid JSON from model: '+str(exc), raw) from exc
        return result, meta

def validate_config(c):
    for k in ['chunk_words', 'top_k', 'context_words', 'repeats', 'memory_k', 'num_ctx', 'num_predict']:
        if not isinstance(c[k], int) or c[k] < 1:
            raise ValueError(f'{k} must be a positive integer')
    if not 0 <= c['chunk_overlap'] < c['chunk_words']:
        raise ValueError('Invalid chunk overlap')
    if not 0 <= c['graph_weight'] <= 1:
        raise ValueError('graph_weight must be between 0 and 1')

def prepare_chunks(docs, config):
    chunks, ids = [], set()
    for d in docs:
        if d['id'] in ids:
            raise ValueError('Duplicate document id')
        ids.add(d['id'])
        if not d.get('text', '').strip() or not d.get('group'):
            raise ValueError('Each document needs text and an incident/report group')
        words = d['text'].split()
        for i, start in enumerate(range(0, len(words), config['chunk_words']-config['chunk_overlap'])):
            text = ' '.join(words[start:start+config['chunk_words']])
            chunks.append({'id': f"{d['id']}::c{i:04d}", 'doc_id': d['id'], 'group': d['group'],
                           'word_start': start, 'text': text, 'source_url': d.get('source_url', '')})
            if start + config['chunk_words'] >= len(words):
                break
    if not chunks:
        raise ValueError('Empty corpus')
    return chunks

def validate_triples(triples, chunk):
    good, bad = [], []
    allowed = {'associated_with', 'part_of', 'reported_cause_of', 'occurred_before', 'mitigated_by'}
    for t in triples:
        valid = isinstance(t, dict) and all(isinstance(t.get(k), str) and t[k].strip()
                                           for k in ['subject', 'relation', 'object', 'evidence'])
        if valid:
            valid = (t['relation'] in allowed and t['evidence'] in chunk['text']
                     and t['subject'] in t['evidence'] and t['object'] in t['evidence'])
        if valid:
            good.append({**t, 'chunk_id': chunk['id']})
        else:
            bad.append({'candidate': t, 'chunk_id': chunk['id'], 'reason': 'schema or verbatim grounding check failed'})
    return good, bad

def build(args):
    cfg, docs = read_json(args.config), read_lines(args.corpus)
    validate_config(cfg)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    backend = Backend(cfg)
    chunks = prepare_chunks(docs, cfg)
    vectors = backend.embed([c['text'] for c in chunks])
    prompt = (ROOT/'prompts/graph.txt').read_text(encoding='utf-8')
    triples, rejected = [], []
    supplied = read_lines(args.triples) if args.triples else None
    if supplied is not None and set(t['chunk_id'] for t in supplied) - {c['id'] for c in chunks}:
        raise ValueError('Triple file contains unknown chunk IDs')
    for ch in chunks:
        if supplied is not None:
            candidates = [t for t in supplied if t['chunk_id'] == ch['id']]
        else:
            result, meta = backend.generate(prompt, ch['text'], cfg['seed'], graph=True)
            candidates = result['triples']
        good, bad = validate_triples(candidates, ch)
        triples.extend(good)
        rejected.extend(bad)
    index = {'config': cfg, 'backend_identity': backend.identity, 'corpus_hash': digest(docs),
             'documents': [{k:v for k,v in d.items() if k != 'text'} for d in docs],
             'chunks': chunks, 'vectors': vectors, 'triples': triples,
             'graph_prompt': prompt, 'graph_reviewed': False,
             'graph_origin': 'provided' if supplied is not None else 'model_extracted'}
    index['index_hash'] = digest(index)
    write_json(out/'index.json', index)
    write_lines(out/'rejected_triples.jsonl', rejected)
    write_lines(out/'construction_calls.jsonl', backend.calls)
    print(f'Index created: {len(chunks)} chunks, {len(triples)} candidate edges. Human graph audit still required.')

def validate_dataset(index, questions, memory):
    ids, chunks = set(), {c['id']: c for c in index['chunks']}
    qgroups = collections.defaultdict(set)
    for q in questions:
        if q['id'] in ids:
            raise ValueError('Duplicate question ID')
        ids.add(q['id'])
        if q['split'] not in ('dev', 'test') or not q.get('question') or not q.get('group'):
            raise ValueError('Question requires dev/test split, question and group')
        if not isinstance(q['answerable'], bool) or not isinstance(q['gold_claims'], list):
            raise ValueError('answerable must be boolean; gold_claims must be a list')
        if q['answerable'] and (not q['evidence_ids'] or not q['gold_claims']):
            raise ValueError('Answerable questions require evidence IDs and gold claims')
        for eid in q['evidence_ids']:
            if eid not in chunks:
                raise ValueError(f'Unknown evidence ID {eid}')
            qgroups[q['split']].add(chunks[eid]['group'])
        qgroups[q['split']].add(q['group'])
    if qgroups['dev'] & qgroups['test']:
        raise ValueError('Development/test incident groups overlap; revise grouped split')
    mids = set()
    for m in memory:
        if m['id'] in mids:
            raise ValueError('Duplicate memory ID')
        mids.add(m['id'])
        if not m.get('approved_by') or not m.get('approved_at') or m['stage'] not in ('initial', 'update'):
            raise ValueError('Memory requires approval identity, timestamp and stage')
        if not m.get('instruction') or not m.get('origin_groups'):
            raise ValueError('Memory needs instruction and provenance groups')
        if set(m['origin_groups']) & qgroups['test']:
            raise ValueError('Memory originated from held-out incident group')
        if set(m['origin_groups']) - qgroups['dev']:
            raise ValueError('Memory origins must be declared development groups')
        if set(m.get('source_question_ids', [])) - {q['id'] for q in questions if q['split']=='dev'}:
            raise ValueError('Memory references non-development question')
        if not isinstance(m.get('aliases', {}), dict):
            raise ValueError('aliases must be a dictionary')
        if not all(isinstance(k,str) and k.strip() and isinstance(v,str) and v.strip() for k,v in m.get('aliases',{}).items()):
            raise ValueError('Memory aliases must map nonempty strings to nonempty strings')
    return True

def memory_text(m):
    return canonical({k: m[k] for k in ['id', 'instruction', 'aliases']})

def retrieve(index, query, qvec, k, weight, use_graph):
    vector_scores = [cosine(qvec, v) for v in index['vectors']]
    order = sorted(range(len(vector_scores)), key=lambda i: (-vector_scores[i], index['chunks'][i]['id']))
    seeds = {index['chunks'][i]['id'] for i in order[:k]}
    # One-hop expansion through shared extracted entities; no formal causal inference.
    entities = set()
    for t in index['triples']:
        if t['chunk_id'] in seeds or t['subject'].lower() in query.lower() or t['object'].lower() in query.lower():
            entities.update([t['subject'].lower(), t['object'].lower()])
    graph_hits, paths = collections.defaultdict(int), collections.defaultdict(list)
    if use_graph:
        for t in index['triples']:
            if t['subject'].lower() in entities or t['object'].lower() in entities:
                graph_hits[t['chunk_id']] += 1
                paths[t['chunk_id']].append(t)
    maximum = max(graph_hits.values(), default=1)
    ranked = []
    for i, ch in enumerate(index['chunks']):
        g = graph_hits[ch['id']] / maximum
        v = (vector_scores[i]+1)/2
        score = (1-weight)*v + weight*g if use_graph else v
        ranked.append({**ch, 'vector_cosine': vector_scores[i], 'graph_score': g,
                       'score': score, 'paths': paths[ch['id']]})
    return sorted(ranked, key=lambda c: (-c['score'], c['id']))[:k]

def make_context(candidates, memories, budget):
    # Same deterministic whitespace-word cap for all grounded conditions. True tokens logged separately.
    chosen_memory, evidence = [], []
    for m in memories:
        size = len(memory_text(m).split())
        if size <= budget:
            chosen_memory.append(m)
            budget -= size
    for c in candidates:
        words = c['text'].split()
        if budget <= 0:
            break
        text = ' '.join(words[:budget])
        evidence.append({'id': c['id'], 'text': text})
        budget -= len(text.split())
    return evidence, chosen_memory

def retrieval_scores(evidence_ids, relevant):
    if not relevant:
        return None
    hits = [int(cid in relevant) for cid in evidence_ids]
    dcg = sum(h/math.log2(i+2) for i,h in enumerate(hits))
    ideal = sum(1/math.log2(i+2) for i in range(min(len(relevant), len(evidence_ids))))
    return {'precision_at_returned': sum(hits)/len(hits) if hits else 0,
            'recall_at_returned': len(set(evidence_ids)&set(relevant))/len(set(relevant)),
            'ndcg_at_returned': dcg/ideal if ideal else 0}

def run(args):
    cfg, index = read_json(args.config), read_json(Path(args.index)/'index.json')
    validate_config(cfg)
    questions, memory = read_lines(args.questions), read_lines(args.memory)
    validate_dataset(index, questions, memory)
    if args.split == 'test' and cfg.get('benchmark_require_freeze'):
        lock_path = ROOT/'data/aaib/freeze.json'
        if not lock_path.exists():
            raise ValueError('Complete the benchmark reviews and run scripts/freeze_benchmark.py before held-out evaluation')
        lock = read_json(lock_path)
        values = {'questions_hash':digest(questions), 'memory_hash':digest(memory), 'index_hash':index['index_hash'], 'config_hash':digest(cfg), 'answer_prompt_hash':hashlib.sha256((ROOT/'prompts/answer.txt').read_bytes()).hexdigest(), 'core_hash':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        if any(lock.get(k)!=v for k,v in values.items()):
            raise ValueError('Frozen inputs changed; resolve and refreeze before a new evaluation')
    original_hash = index.pop('index_hash')
    if digest(index) != original_hash:
        raise ValueError('Index has changed after build; rebuild instead of editing it')
    index['index_hash'] = original_hash
    for k in ['backend', 'embedding_model', 'chunk_words', 'chunk_overlap', 'embedding_document_prefix', 'embedding_query_prefix']:
        if cfg.get(k) != index['config'].get(k):
            raise ValueError(f'Index incompatible with config: {k}')
    backend = Backend(cfg)
    if cfg['backend']=='ollama' and backend.identity['embedding_model'] != index['backend_identity']['embedding_model']:
        raise ValueError('Embedding model digest changed; rebuild index')
    selected = [q for q in questions if q['split']==args.split]
    if not selected:
        raise ValueError('No questions in selected split')
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    prompt = (ROOT/'prompts/answer.txt').read_text(encoding='utf-8')
    manifest = {'status': 'DEMONSTRATION_NOT_RESEARCH' if cfg['backend']=='demo' else cfg.get('dataset_status', 'RESEARCH_CANDIDATE_UNAUDITED'),
                'config': cfg, 'index_hash': original_hash, 'questions_hash': digest(questions),
                'memory_hash': digest(memory), 'backend_identity': backend.identity,
                'python': sys.version, 'platform': platform.platform(), 'split': args.split,
                'answer_prompt': prompt, 'conditions': CONDITIONS,
                'source_hash': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    write_json(out/'manifest.json', manifest)
    write_lines(out/'questions_snapshot.jsonl', questions)
    write_lines(out/'memory_snapshot.jsonl', memory)
    write_json(out/'source_chunks.json', index['chunks'])
    # Retrieval and memory embeddings cached across repeats and conditions.
    qvectors = dict(zip([q['id'] for q in selected], backend.embed([q['question'] for q in selected], role='query')))
    mvectors = dict(zip([m['id'] for m in memory], backend.embed([memory_text(m) for m in memory])))
    query_cache = {}
    jobs = [(q, cond, repeat) for q in selected for cond in CONDITIONS for repeat in range(cfg['repeats'])]
    random.Random(cfg['seed']).shuffle(jobs)
    with (out/'answers.jsonl').open('w', encoding='utf-8') as fh:
        for q, cond, repeat in jobs:
            started = time.perf_counter()
            used_memory = []
            if cond in ('clkm_static', 'clkm_updated', 'vector_notes'):
                eligible = [m for m in memory if (cond != 'clkm_static' or m['stage']=='initial') and (not m.get('trigger_terms') or any(re.search(r'(?<!\w)'+re.escape(term)+r'(?!\w)',q['question'],re.I) for term in m['trigger_terms']))]
                used_memory = sorted(eligible, key=lambda m: (-cosine(qvectors[q['id']], mvectors[m['id']]), m['id']))[:cfg['memory_k']]
            # Reserve memory budget before expansion so excluded entries cannot change retrieval.
            _, used_memory = make_context([], used_memory, cfg['context_words'])
            expanded = q['question']
            if cond in ('clkm_static', 'clkm_updated'):
                for m in used_memory:
                    for alias, entity in m['aliases'].items():
                        if re.search(r'(?<!\w)' + re.escape(alias) + r'(?!\w)', expanded, re.I):
                            expanded += ' ' + entity
            if expanded not in query_cache:
                query_cache[expanded] = qvectors[q['id']] if expanded == q['question'] else backend.embed([expanded], role='query')[0]
            candidates = [] if cond=='llm_only' else retrieve(index, expanded, query_cache[expanded], cfg['top_k'], cfg['graph_weight'], cond in ('kg_rag', 'clkm_static', 'clkm_updated'))
            evidence, used_memory = make_context(candidates, used_memory, cfg['context_words'])
            # Both memory and information-matched control carry identical selected guidance content.
            user = canonical({'question': q['question'], 'expert_guidance': [memory_text(m) for m in used_memory], 'evidence': evidence})
            row = {'run_id': f"{q['id']}|{cond}|{repeat}", 'question_id': q['id'], 'group': q['group'],
                   'condition': cond, 'repeat': repeat, 'seed': cfg['seed']+repeat,
                   'expanded_query': expanded, 'retrieved': candidates, 'evidence': evidence,
                   'memory_ids': [m['id'] for m in used_memory], 'system_prompt': prompt, 'user_prompt': user,
                   'retrieval': None if cond=='llm_only' else retrieval_scores([e['id'] for e in evidence], q['evidence_ids'])}
            try:
                result, meta = backend.generate(prompt, user, cfg['seed']+repeat)
                if not isinstance(result.get('answer'), str) or not isinstance(result.get('citations'), list) or not all(isinstance(x,str) for x in result['citations']):
                    raise ValueError('Invalid answer JSON schema')
                row.update({'answer': result['answer'], 'citations': result['citations'], 'generation': meta,
                            'invalid_citations': sorted(set(result['citations'])-{e['id'] for e in evidence}), 'error': None})
            except Exception as exc:
                row.update({'answer': '', 'citations': [], 'invalid_citations': [], 'error': str(exc),
                            'failed_raw_output': getattr(exc, 'raw', None)})
            row['pipeline_seconds'] = time.perf_counter()-started
            fh.write(canonical(row)+'\n')
            fh.flush()
            print(f"Completed {row['run_id']}: {'ERROR' if row['error'] else 'OK'}", flush=True)
    write_lines(out/'backend_calls.jsonl', backend.calls)
    print(f'Saved {len(jobs)} runs to {out}; human scoring required. {manifest["status"]}')

def prf(tp, fp, fn):
    p = tp/(tp+fp) if tp+fp else 0.0
    r = tp/(tp+fn) if tp+fn else 0.0
    f = 2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.0
    return p, r, f

def export_review(args):
    run_dir = Path(args.run)
    rows = read_lines(run_dir/'answers.jsonl')
    questions = {q['id']:q for q in read_lines(run_dir/'questions_snapshot.jsonl')}
    source_chunks = {c['id']:c for c in read_json(run_dir/'source_chunks.json')}
    random.Random(args.seed).shuffle(rows)
    cases, key = [], []
    for i, row in enumerate(rows):
        blind_id = f'case-{i+1:05d}'
        q = questions[row['question_id']]
        cases.append({'blind_id': blind_id, 'question': q['question'], 'gold_claims': q['gold_claims'],
                      'reference_answer': q.get('reference_answer', ''), 'answerable': q['answerable'],
                      'answer': row['answer'], 'evidence': row['evidence'], 'citations': row['citations'],
                      'reference_evidence': [source_chunks[cid] for cid in dict.fromkeys(q['evidence_ids'] + [cid for support in q.get('source_support', []) for cid in support['evidence_ids']])],
                      'gold_evidence_ids': q['evidence_ids'], 'error': row['error']})
        key.append({'blind_id': blind_id, 'run_id': row['run_id']})
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    write_lines(out/'private_key.jsonl', key)
    write_json(out/'review_cases.json', cases)
    template = (ROOT/'aihc/review_template.html').read_text(encoding='utf-8')
    payload = json.dumps(cases).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    (out/'review.html').write_text(template.replace('__CASES__', payload), encoding='utf-8')
    print(f'Open {out}/review.html. Keep private_key.jsonl from raters. Supply corpus/index for full source checks.')

def percentile(values, fraction):
    vals = sorted(values)
    return vals[round((len(vals)-1)*fraction)]

def score(args):
    base = Path(args.run)
    rows = read_lines(base/'answers.jsonl')
    by_id = {r['run_id']:r for r in rows}
    questions = {q['id']:q for q in read_lines(base/'questions_snapshot.jsonl')}
    key = {r['blind_id']:r['run_id'] for r in read_lines(args.key)}
    with open(args.ratings, newline='', encoding='utf-8-sig') as f:
        ratings = list(csv.DictReader(f))
    seen, scored = set(), []
    for a in ratings:
        rid = key[a['blind_id']]
        if rid in seen:
            raise ValueError('Duplicate ratings; supply one adjudicated rating per run')
        seen.add(rid)
        row = by_id[rid]
        q = questions[row['question_id']]
        counts = [int(a[k]) for k in ['tp','fp','fn']]
        if min(counts)<0 or not a['rater'].strip():
            raise ValueError('Ratings need nonnegative counts and rater ID')
        if counts[0] + counts[2] != len(q['gold_claims']):
            raise ValueError(f'{rid}: TP+FN must equal number of annotated gold claims')
        abstention = int(a['appropriate_abstention'])
        if abstention not in (0,1):
            raise ValueError('appropriate_abstention must be 0 or 1')
        if row['error'] and (counts[0] != 0 or abstention != 0):
            raise ValueError('Generation failures must receive zero TP and no abstention credit')
        p,r,f1 = prf(*counts)
        scored.append({**row, 'tp':counts[0], 'fp':counts[1], 'fn':counts[2],
                       'precision':p, 'recall':r, 'f1':f1, 'answerable':q['answerable'],
                       'appropriate_abstention':abstention})
    if seen != set(by_id):
        raise ValueError(f'Incomplete scoring: {len(seen)}/{len(by_id)}. Do not silently omit failures.')
    if args.task:
        scored = [r for r in scored if questions[r['question_id']].get('task')==args.task]
        if not scored:
            raise ValueError('No questions match requested task category')
    summaries = {}
    for cond in CONDITIONS:
        items = [r for r in scored if r['condition']==cond]
        answerable = [r for r in items if r['answerable']]
        sums = [sum(r[k] for r in answerable) for k in ('tp','fp','fn')]
        macro = {k: statistics.mean(r[k] for r in answerable) if answerable else None for k in ('precision','recall','f1')}
        neg = [r for r in items if not r['answerable']]
        retrieval = [r['retrieval'] for r in items if r['retrieval'] is not None]
        summaries[cond] = {'runs':len(items), 'macro_answerable':macro,
                           'micro_answerable':dict(zip(['precision','recall','f1'],prf(*sums))),
                           'abstention_accuracy_unanswerable':statistics.mean(r['appropriate_abstention'] for r in neg) if neg else None,
                           'failures':sum(bool(r['error']) for r in items),
                           'runs_with_invalid_citations':sum(bool(r['invalid_citations']) for r in items),
                           'retrieval':{k:statistics.mean(r[k] for r in retrieval) for k in retrieval[0]} if retrieval else None,
                           'median_pipeline_seconds':statistics.median(r['pipeline_seconds'] for r in items)}
    # Average repeats within question, then paired cluster bootstrap by incident group.
    means = {}
    for cond in CONDITIONS:
        grouped = collections.defaultdict(list)
        for row in scored:
            if row['condition']==cond and row['answerable']:
                grouped[row['question_id']].append(row['f1'])
        means[cond] = {qid:statistics.mean(v) for qid,v in grouped.items()}
    comparisons = {}
    for a,b in [('clkm_updated','vector_rag'),('clkm_updated','llm_only'),('kg_rag','vector_rag'),('clkm_static','kg_rag'),('clkm_updated','clkm_static'),('clkm_updated','vector_notes')]:
        groups = collections.defaultdict(list)
        for qid in means[a]:
            groups[questions[qid]['group']].append(means[a][qid]-means[b][qid])
        vals = [x for group in groups.values() for x in group]
        rng, draws, names = random.Random(17), [], sorted(groups)
        if len(names)>=2:
            for _ in range(2000):
                sample = [x for name in rng.choices(names,k=len(names)) for x in groups[name]]
                draws.append(statistics.mean(sample))
        comparisons[a+' minus '+b] = {'mean_question_f1_difference':statistics.mean(vals) if vals else None,
               'incident_clusters':len(names), 'percentile_95_ci':[percentile(draws,.025),percentile(draws,.975)] if draws else None}
    report = {'run_status':read_json(base/'manifest.json')['status'], 'task_filter':args.task, 'conditions':summaries,
              'paired_comparisons':comparisons, 'retrieval_label_scope':read_json(base/'manifest.json')['config'].get('retrieval_label_scope', 'unspecified'), 'warning':'Exploratory intervals; inspect cluster counts and predeclared primary contrast. Human annotation required; synthetic runs are never research evidence.'}
    write_json(args.out, report)
    print(f'Scored report saved to {args.out}')

def ingest(args):
    manifest = read_lines(args.manifest)
    base = Path(args.manifest).resolve().parent
    docs = []
    for m in manifest:
        path = base/m['path']
        if path.suffix.lower()=='.pdf':
            from pypdf import PdfReader
            text = '\n\n'.join(p.extract_text() or '' for p in PdfReader(path).pages)
        else:
            text = path.read_text(encoding='utf-8')
        if not text.strip():
            raise ValueError(f'No extractable text in {path}; OCR and verify manually')
        docs.append({**m, 'text':text, 'file_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    write_lines(args.out, docs)
    print(f'Imported {len(docs)} documents. Inspect extraction before freezing chunks.')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command',required=True)
    x = sub.add_parser('ingest'); x.add_argument('--manifest',required=True); x.add_argument('--out',required=True); x.set_defaults(func=ingest)
    x = sub.add_parser('build')
    for k in ['config','corpus','out']: x.add_argument('--'+k,required=True)
    x.add_argument('--triples'); x.set_defaults(func=build)
    x = sub.add_parser('run')
    for k in ['config','index','questions','memory','out']: x.add_argument('--'+k,required=True)
    x.add_argument('--split',choices=['dev','test'],default='dev'); x.set_defaults(func=run)
    x = sub.add_parser('review')
    for k in ['run','out']: x.add_argument('--'+k,required=True)
    x.add_argument('--seed',type=int,default=31); x.set_defaults(func=export_review)
    x = sub.add_parser('score')
    for k in ['run','ratings','key','out']: x.add_argument('--'+k,required=True)
    x.add_argument('--task',help='Prespecified task category; still requires complete ratings for the run')
    x.set_defaults(func=score)
    args = p.parse_args()
    args.func(args)

if __name__ == '__main__':
    main()
