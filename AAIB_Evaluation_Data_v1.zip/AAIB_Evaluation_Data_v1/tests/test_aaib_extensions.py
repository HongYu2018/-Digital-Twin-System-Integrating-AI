import unittest,tempfile,subprocess,sys,json
from pathlib import Path
from unittest.mock import patch
from aihc.core import ROOT,Backend,read_json,read_lines,prepare_chunks,validate_dataset
class AAIBExtensions(unittest.TestCase):
 def test_embedding_role_prefixes(self):
  backend=object.__new__(Backend);backend.c={'backend':'ollama','embedding_model':'x','embedding_document_prefix':'search_document: ','embedding_query_prefix':'search_query: '};backend.calls=[]
  with patch.object(backend,'http',return_value={'embeddings':[[1.,0.]]}) as http:
   backend.embed(['same text']);self.assertEqual(http.call_args.args[1]['input'],['search_document: same text'])
   backend.embed(['same text'],role='query');self.assertEqual(http.call_args.args[1]['input'],['search_query: same text'])
 def test_aaib_provenance_and_negative_sources(self):
  cfg=read_json(ROOT/'configs/aaib_dev.json');docs=read_lines(ROOT/'data/aaib/corpus.jsonl');qs=read_lines(ROOT/'data/aaib/questions.jsonl');memory=read_lines(ROOT/'data/aaib/memory.jsonl')
  self.assertTrue(validate_dataset({'chunks':prepare_chunks(docs,cfg)},qs,memory));bydoc={d['id']:d for d in docs}
  for q in qs:
   self.assertTrue(q['source_support'])
   for s in q['source_support']:self.assertEqual(bydoc[s['report_id']]['text'][s['char_start']:s['char_end']],s['quote'])
   if not q['answerable']:self.assertEqual(q['gold_claims'],[]);self.assertEqual(q['evidence_ids'],[])
 def test_checkpoint_resume_preserves_complete_index(self):
  with tempfile.TemporaryDirectory() as t:
   out=Path(t)/'index';cmd=[sys.executable,str(ROOT/'scripts/build_index.py'),'--config',str(ROOT/'configs/demo.json'),'--corpus',str(ROOT/'data/demo/corpus.jsonl'),'--out',str(out)]
   subprocess.run(cmd,check=True,capture_output=True,text=True);before=(out/'index.json').read_bytes()
   result=subprocess.run(cmd,check=True,capture_output=True,text=True)
   self.assertIn('already complete',result.stdout);self.assertEqual(before,(out/'index.json').read_bytes())
if __name__=='__main__':unittest.main()
