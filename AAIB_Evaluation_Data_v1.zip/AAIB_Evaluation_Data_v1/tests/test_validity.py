import copy
import csv
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from aihc.core import (ROOT, Backend, ModelOutputError, digest, make_context, prf,
                       prepare_chunks, read_json, read_lines, retrieval_scores,
                       validate_dataset, validate_triples)

class ValidityTests(unittest.TestCase):
    def setUp(self):
        self.cfg = read_json(ROOT/'configs/demo.json')
        self.docs = read_lines(ROOT/'data/demo/corpus.jsonl')
        self.q = read_lines(ROOT/'data/demo/questions.jsonl')
        self.m = read_lines(ROOT/'data/demo/memory.jsonl')
        self.index = {'chunks': prepare_chunks(self.docs,self.cfg)}

    def test_metric_known_counts(self):
        p,r,f = prf(3,1,2)
        self.assertAlmostEqual(p,.75); self.assertAlmostEqual(r,.6); self.assertAlmostEqual(f,2/3)
        self.assertEqual(prf(0,0,0),(0,0,0))
        self.assertEqual(prf(0,0,4),(0,0,0))

    def test_macro_f1_cannot_exceed_both_means(self):
        vals=[prf(1,8,0),prf(1,0,8),prf(5,2,3)]
        means=[sum(v[i] for v in vals)/len(vals) for i in range(3)]
        self.assertLessEqual(means[2],max(means[:2]))

    def test_valid_split(self):
        self.assertTrue(validate_dataset(self.index,self.q,self.m))

    def test_test_derived_memory_rejected(self):
        self.m[0]['origin_groups']=['alpha-incident']
        with self.assertRaisesRegex(ValueError,'held-out'):
            validate_dataset(self.index,self.q,self.m)

    def test_cross_report_split_leakage_rejected(self):
        self.q[0]['evidence_ids']=['demo-alpha::c0000']
        with self.assertRaisesRegex(ValueError,'overlap'):
            validate_dataset(self.index,self.q,self.m)

    def test_unknown_evidence_rejected(self):
        self.q[0]['evidence_ids']=['made-up']
        with self.assertRaisesRegex(ValueError,'Unknown evidence'):
            validate_dataset(self.index,self.q,self.m)

    def test_graph_grounding(self):
        ch=self.index['chunks'][1]
        good=read_lines(ROOT/'data/demo/triples.jsonl')[1]
        bad={**good,'evidence':'invented causal assertion'}
        accepted,rejected=validate_triples([good,bad],ch)
        self.assertEqual(len(accepted),1);self.assertEqual(len(rejected),1)

    def test_budget_and_memory(self):
        e,m=make_context(self.index['chunks'],self.m,70)
        used=sum(len(x['text'].split()) for x in e)
        from aihc.core import memory_text
        used+=sum(len(memory_text(x).split()) for x in m)
        self.assertLessEqual(used,70)

    def test_retrieval_known_values(self):
        s=retrieval_scores(['a','b'],['b','c'])
        self.assertEqual(s['precision_at_returned'],.5)
        self.assertEqual(s['recall_at_returned'],.5)
        self.assertIsNone(retrieval_scores([],[]))

    def test_mock_ollama_contract_and_bad_json(self):
        cfg={**self.cfg,'backend':'ollama','generation_model':'gen','embedding_model':'embed'}
        calls=[]
        def fake(obj,path,payload=None):
            calls.append((path,payload))
            if path=='/api/version':return {'version':'test'}
            if path=='/api/tags':return {'models':[{'name':'gen:latest','digest':'g1'},{'name':'embed:latest','digest':'e1'}]}
            if path=='/api/embed':return {'embeddings':[[1,0] for _ in payload['input']]}
            return {'message':{'content':'not JSON'},'prompt_eval_count':9,'eval_count':3}
        with patch.object(Backend,'http',fake):
            b=Backend(cfg)
            self.assertEqual(b.embed(['hello']),[[1,0]])
            with self.assertRaises(ModelOutputError) as e:b.generate('sys','question',42)
            self.assertEqual(e.exception.raw,'not JSON')
            self.assertFalse(calls[-1][1]['stream'])
            self.assertEqual(calls[-1][1]['options']['seed'],42)

    def test_end_to_end_and_scoring_completeness(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)
            def cli(*args, success=True):
                result=subprocess.run([sys.executable,'-m','aihc.core',*map(str,args)],cwd=ROOT,capture_output=True,text=True)
                if success:self.assertEqual(result.returncode,0,result.stderr)
                else:self.assertNotEqual(result.returncode,0)
                return result
            cli('build','--config','configs/demo.json','--corpus','data/demo/corpus.jsonl','--triples','data/demo/triples.jsonl','--out',p/'index')
            cli('run','--config','configs/demo.json','--index',p/'index','--questions','data/demo/questions.jsonl','--memory','data/demo/memory.jsonl','--split','test','--out',p/'run')
            answers=read_lines(p/'run/answers.jsonl')
            self.assertEqual(len(answers),18)
            self.assertTrue(all(not r['error'] for r in answers))
            self.assertTrue(all('gold_claims' not in r['user_prompt'] for r in answers))
            self.assertEqual({r['condition'] for r in answers}, {'llm_only','vector_rag','kg_rag','clkm_static','clkm_updated','vector_notes'})
            self.assertTrue(all(not r['memory_ids'] for r in answers if r['condition']=='kg_rag'))
            updated=next(r for r in answers if r['question_id']=='test-001' and r['condition']=='clkm_updated')
            self.assertIn('fuel pump unit',updated['expanded_query'])
            notes=next(r for r in answers if r['question_id']=='test-001' and r['condition']=='vector_notes')
            self.assertEqual(updated['memory_ids'],notes['memory_ids'])
            cli('review','--run',p/'run','--out',p/'review')
            cases=read_json(p/'review/review_cases.json')
            self.assertNotIn('condition',cases[0])
            self.assertIn('reference_evidence',cases[0])
            # Mechanical fixture: assign every answer zero TP. NOT a human assessment.
            fields=['blind_id','rater','tp','fp','fn','appropriate_abstention','notes']
            ratings=p/'fixture.csv'
            with ratings.open('w',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
                for c in cases:writer.writerow({'blind_id':c['blind_id'],'rater':'TEST_FIXTURE','tp':0,'fp':0,'fn':len(c['gold_claims']),'appropriate_abstention':0,'notes':'NOT HUMAN RATINGS'})
            cli('score','--run',p/'run','--ratings',ratings,'--key',p/'review/private_key.jsonl','--out',p/'score.json')
            report=read_json(p/'score.json')
            self.assertEqual(report['run_status'],'DEMONSTRATION_NOT_RESEARCH')
            for v in report['conditions'].values():self.assertEqual(v['macro_answerable']['f1'],0)
            lines=ratings.read_text().splitlines();ratings.write_text('\n'.join(lines[:-1])+'\n')
            result=cli('score','--run',p/'run','--ratings',ratings,'--key',p/'review/private_key.jsonl','--out',p/'incomplete.json',success=False)
            self.assertIn('Incomplete scoring',result.stderr)

if __name__=='__main__':unittest.main()
