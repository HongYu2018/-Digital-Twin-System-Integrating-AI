# AAIB revision evaluation — source-grounded draft v1

Prepared 22 September 2026 for the AIHC manuscript revision. This is a **new research reconstruction**, not recovery or verification of the transferred industrial implementation. No Ollama performance results or human approvals are included.

## Contents

- 18 real AAIB field-investigation reports, with URLs, PDF SHA-256 hashes, extracted source text and saved official metadata.
- 505 deterministic 250-word chunks with 40-word overlap.
- 80 source-linked reference questions: 22 development and 58 test; 74 answerable and 6 requests for information explicitly not established by the source.
- Development: 5 reports / 5 incident clusters. Test: 13 reports / 11 incident clusters. Two pairs are grouped because cross-report questions reuse their evidence.
- Draft CLKM: 1 initial instruction and 2 development-derived updates. Human approval is pending.
- Six conditions: LLM only, vector RAG, one-hop KG-RAG, KG-RAG with static CLKM, KG-RAG with updated CLKM, vector RAG with identical updated guidance.
- Offline reference-review pages, blinded output-rating interface, metric calculation, paired cluster bootstrap, and CSV export after human scoring.
- A checkpointed index builder and reproducibility logs. Python standard library only; no pip install needed for the supplied corpus.

**This dataset tests claims; it cannot guarantee that CLKM or graph retrieval will improve results.** Its reference answers were AI-authored and checked against extracted source passages. Domain experts must validate them and the extracted graph before final testing. Questions sharing a source or paraphrasing the same uncertainty are not independent observations.

## Start on your Windows computer

Extract this ZIP to a **new folder**, keeping your original pilot unchanged. Open PowerShell in the folder containing this README, `aihc`, `configs` and `scripts`. Ollama must be running with `qwen2.5:7b` and `nomic-embed-text` installed, as on your current computer.

```powershell
python scripts/validate_data.py
python -m unittest discover -s tests -v
```

Start with the five development reports:

```powershell
python scripts/build_index.py --config configs/aaib_dev.json --corpus data/aaib/corpus_dev.jsonl --out work/aaib-dev-index
```

The builder prints embedding and graph progress. If interrupted or a model response is invalid, rerun the **same command** to resume. It retains successful chunks and logs failures; it does not silently drop bad responses. Persistent failure needs diagnosis rather than repeated retries. Changes to model, configuration, source or code require a new output directory. The original three-chunk pilot index is incompatible with these embedding prefixes.

Then run a development pilot (22 questions × 6 conditions × 1 repeat = 132 responses):

```powershell
python -m aihc.core run --config configs/aaib_dev.json --index work/aaib-dev-index --questions data/aaib/questions_dev.jsonl --memory data/aaib/memory.jsonl --split dev --out work/aaib-dev-run
python -m aihc.core review --run work/aaib-dev-run --out work/aaib-dev-review
Start-Process work/aaib-dev-review/review.html
Start-Process review/dev_references.html
```

The answer runner records failures and continues, but does not resume interrupted runs. Preserve an interrupted folder and use a fresh output folder; never silently combine selected successful responses. The index builder does resume. Runtime is unknown until your development run completes.

## Review and freeze before held-out evaluation

1. Read `docs/PROTOCOL.md` and `docs/ANNOTATION_GUIDE.md` before changing parameters.
2. Have reference reviewers inspect `review/dev_references.html` and `review/test_references.html` against the linked original PDFs. Record decisions in the matching CSVs. Ideally the test-reference reviewer is separate from the developer. Do not use test answers or outputs to tune prompts, graph extraction, memory or thresholds.
3. Correct reference errors in `data/aaib/questions.jsonl`; resolve all decisions to `accept` only after correction. `reviewer_id` and `reviewed_at` must identify a real review. If excluding questions, remove their CSV rows too, update counts and record reasons before freezing. Keep the development-only questions file synchronized. The authoring scripts regenerate drafts and can overwrite edits: do not rerun them after manual review.
4. Review `data/aaib/memory.jsonl`. For genuinely accepted entries, set `review_status` to `accepted`, `approved_by` to the actual reviewer ID, and `approved_at` to the review date. Preserve development provenance; do not insert test findings. These are curated offline updates, not proof of a human interaction study.
5. Once development choices are fixed, build the full index, and audit its candidate edges. Decide `accept` or `reject` and enter a reviewer ID for **each** row of `graph_audit.csv`. Verbatim grounding alone does not establish relation correctness. Do not edit `index.json` directly.

```powershell
python scripts/build_index.py --config configs/aaib_evaluation.json --corpus data/aaib/corpus.jsonl --out work/aaib-full-index
```

The final build covers all 18 source reports. Finish graph review, then:

```powershell
python scripts/validate_data.py
python scripts/freeze_benchmark.py --index work/aaib-full-index
python -m aihc.core run --config configs/aaib_frozen.json --index work/aaib-full-index-reviewed --questions data/aaib/questions.jsonl --memory data/aaib/memory.jsonl --split test --out work/aaib-test-run
```

The efficient default gives 58 × 6 × 1 = **348 test responses**. This is a single-run comparison and does not measure run-to-run variability. If resources permit, predeclare three repeats before freezing (1,044 responses), use them consistently and report stability. At temperature zero repeats may be identical and do not create independent test cases. Never choose the repeat count after inspecting which scores look best.

The freeze command creates a separate reviewed index and records data, prompts, configuration, code and review hashes. It checks records, not reviewer qualifications. It intentionally refuses draft test runs through the supplied configurations. This prevents accidental reporting of unreviewed reference data.

## Score and export tables

```powershell
python -m aihc.core review --run work/aaib-test-run --out work/aaib-test-review
Start-Process work/aaib-test-review/review.html
```

Give raters the HTML and annotation guide; withhold `private_key.jsonl`. Reviewers enter genuine TP/FP/FN and abstention decisions and download ratings CSV. Use independent ratings and adjudication where feasible. Copy the complete adjudicated CSV to `work/aaib-test-review/ratings.csv`.

```powershell
python -m aihc.core score --run work/aaib-test-run --ratings work/aaib-test-review/ratings.csv --key work/aaib-test-review/private_key.jsonl --out work/aaib-test-scores.json
python scripts/export_tables.py --scores work/aaib-test-scores.json --out work/aaib-test-tables
```

Outputs include macro/micro precision, recall and F1; abstention accuracy; failures; invalid citation IDs; latency; and paired differences with exploratory incident-cluster bootstrap intervals. The CSV export excludes retrieval metrics because the shipped reference-passage labels are incomplete relevance judgments. See the protocol before interpreting them.

For reviewer sharing, retain the frozen package, exact model digests, configuration and prompts, reviewed index, reference decisions, anonymized ratings, adjudication record, raw outputs and score files. Remove personal reviewer identities from a public release if necessary, preserving stable anonymous IDs and approval provenance. No code or original industrial results are recovered by this process.
