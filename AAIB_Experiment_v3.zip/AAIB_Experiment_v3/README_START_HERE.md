# Version 3: preserve five vector results; expand from three seeds

This version implements the retrieval sequence clarified in our discussion. It does not claim new accuracy results or a completed reconstruction of the original deployed system.

## Next step on your computer

Extract into a NEW folder, retaining v2. Start Ollama. Open PowerShell in this folder and run:

```powershell
python prepare_dev.py
```

On first use it asks for the path to your existing DEVELOPMENT `index.json` (or its folder). This is usually inside the previous experiment's `work/index-dev/` folder. Paste the full path, with or without quotes. The script verifies corpus and embedding settings, reuses its vectors/triples and writes a separate v3 index. The previous index is not overwritten. Do not supply a pilot or full/test index.

The script then creates a retrieval-only preflight for all six configurations on the 22 development questions. It embeds queries and guidance using Ollama but makes NO answer-generation calls. ZIP `work/dev-preflight-v3` and return it for inspection. In particular, inspect `preflight_summary.json` for blocked payloads and evidence counts before a full run.

If the existing index is unavailable, build a new development index with `python experiment.py build --scope dev`; this is slower and may regenerate graph candidates. Preserve that new index and its provenance.

## Exact implemented retrieval

1. Vector-rank the scoped corpus, taking the first five (or all if fewer exist).
2. Preserve these chunks in their initial order.
3. For hybrid configurations, use ONLY the first three as expansion seeds.
4. Append their direct one-hop neighbours, deduplicated. No recursive expansion. No reranking. No final top-five cut-off.
5. Order additional chunks by stable chunk ID solely for reproducibility, not by a new relevance score.
6. Select CLKM guidance after retrieval. It cannot change scores, seeds, membership or order. Memory applicability uses the original vector evidence consistently across vector/hybrid conditions.

Graph edges remain undirected adjacency (`NEXT`) and shared entity (`SAME_ENTITY`) links. Both directions count as one-hop neighbours. Each added chunk records its expansion paths. Complete induced links among supplied chunks are included in the model payload, without the former 24-link cut-off. Within the existing report-scoping mechanism, neighbours are taken from the scoped graph; cross-report expansion is not newly enabled.

## Context policy

The application sends every selected chunk in full or blocks the payload. It does not slice evidence, remove neighbours, or drop the original five to fit a budget. Every row records word count and a conservative byte-based token screen, including the serialized payload, prompt, schema, output reserve and overhead allowance. This screen is NOT exact model-specific tokenization and cannot certify every backend's behaviour.

The default common limits are now 6,000 evidence-plus-guidance words, 16,384 model context tokens and 1,536 output tokens. These are changes from v2 and are logged in the manifest. A longer model context may increase memory use and offloading on an 8 GB GPU; preflight itself makes no generation calls. If payloads exceed the limits, inspect them and choose a common configuration for a NEW run. Do not selectively shorten only an unfavourable condition. Hybrid systems now legitimately receive more evidence than vector-only systems; this is an architecture comparison, not an equal-token efficiency benchmark. Record context sizes and runtime when reporting results.

## Scope and remaining limitations

This patch corrects retrieval and removes CLKM retrieval bonuses. It does NOT implement automatic KG-to-CLKM abstraction, human experience capture, or continual updating. The supplied CLKM remains the earlier prepared development guidance with its existing provenance. Do not describe it as learned from KG updates. Report-level scoping and instruction-based incident attribution remain; explicit incident-level graph attribution is still future work. Fixed word chunks have not been changed, so chunk boundary defects can remain even though retrieved chunks are now sent whole.

No existing data labels, reference answers or original results were revised by this patch. No unseen test set was evaluated. Historical documentation is in `docs/historical_v2/` and does not define the v3 protocol; this README is authoritative for v3 changes.

## After the preflight has been inspected

A fresh generation command, using a different output directory from preflight, is:

```powershell
python experiment.py run --split dev --task open --out work/dev-open-v3
```

Resume only with the identical command/settings. Runtime failures, output-limit failures and blocked payloads remain recorded. Preflight records cannot be scored as generated answers. Open answers still need semantic assessment; the legacy selection scorer measures a different task and must not be reported as open-answer quality.

## Validation

```powershell
python -m unittest discover -s tests -v
```

The package was checked offline, including mocked generation integration and new retrieval invariants. No live Ollama evaluation was performed in the preparation environment. Dependencies and the unchanged corpus come from v2; this update needs no additional Python package.
