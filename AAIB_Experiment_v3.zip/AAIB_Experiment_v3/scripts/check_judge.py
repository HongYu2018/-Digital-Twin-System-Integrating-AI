"""Fixed controls for judge semantics; not domain validation or model-performance evidence."""
from pathlib import Path
import sys,argparse,json,hashlib
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from aihc.core import Backend,write_json
CASES=[
('The duration cannot be established from supplied information.','The outage lasted three seconds.','not_stated'),
('The outage lasted approximately three seconds.','The outage lasted about three seconds.','entailed'),
('The outage lasted thirty seconds.','The outage lasted three seconds.','contradicted'),
('The intended route is unknown.','The flight was from Retreat Farm to Nayland.','not_stated'),
('The flight departed Retreat Farm for Nayland.','Nayland was the intended destination.','entailed'),
('The flight departed Nayland for Retreat Farm.','Nayland was the intended destination.','contradicted'),
('The bearing was too damaged to identify the initiating cause.','Damage prevented identification of the initial cause.','entailed'),
('No information about the bearing examination is supplied.','Bearing damage prevented identification of the initial cause.','not_stated'),
('The aircraft bounced twice after initial touchdown.','The aircraft bounced four times.','contradicted'),
('The aircraft bounced twice after initial touchdown.','There were two bounces.','entailed'),
('The pilot and passenger were uninjured.','The pilot was uninjured.','entailed'),
('The pilot was uninjured.','Both the pilot and passenger were uninjured.','not_stated'),
('A role for maintenance was possible, but the cause was not determined.','Maintenance was proven to be the cause.','contradicted'),
('The contactor contributed but did not initiate the power loss.','The contactor was an initiating cause.','contradicted'),
('Rig tests discounted the initial explanation.','Rig tests confirmed the initial explanation.','contradicted'),
('The club improved weather reporting.','The club improved weather reporting and replaced all engines.','not_stated')]
PROMPT='Does the PREMISE alone establish every part of the HYPOTHESIS? Return entailed only if it does. Return contradicted for explicit conflict. Otherwise return not_stated. The hypothesis is not evidence. A refusal or missing information never establishes a specific duration, route or event. Do not use background knowledge. Return only the requested JSON.'
def main():
 p=argparse.ArgumentParser();p.add_argument('--model',default='llama3.1:8b');p.add_argument('--out',default='work/judge_validation.json');a=p.parse_args();cfg=json.loads((ROOT/'configs/experiment.json').read_text());cfg['generation_model']=a.model;b=Backend(cfg);rows=[]
 schema={'type':'object','properties':{'verdict':{'type':'string','enum':['entailed','contradicted','not_stated']}},'required':['verdict'],'additionalProperties':False}
 for i,(premise,hypothesis,expected) in enumerate(CASES):
  raw=b.http('/api/chat',{'model':a.model,'stream':False,'format':schema,'messages':[{'role':'system','content':PROMPT},{'role':'user','content':json.dumps({'premise':premise,'hypothesis':hypothesis})}],'options':{'temperature':0,'seed':17,'num_ctx':2048,'num_predict':64}})
  try:verdict=json.loads(raw['message']['content'])['verdict']
  except Exception:verdict='INVALID'
  rows.append({'id':i,'premise':premise,'hypothesis':hypothesis,'expected':expected,'actual':verdict,'correct':verdict==expected,'raw':raw});print(f'Control {i+1}/{len(CASES)}: {verdict==expected}',flush=True)
 passed=all(r['correct'] for r in rows);write_json(a.out,{'status':'CONTROLS_PASSED_NOT_DOMAIN_VALIDATED' if passed else 'JUDGE_FAILED_CONTROLS','model':b.identity,'prompt':PROMPT,'cases':rows,'correct':sum(r['correct'] for r in rows),'total':len(rows),'pass_rule':'All 16 fixed controls must pass. No tuning on benchmark test outputs.','code_hash':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
 print('Judge controls:',sum(r['correct'] for r in rows),'/',len(rows),'— not domain validation of free-text scores.')
 return 0 if passed else 2
if __name__=='__main__':sys.exit(main())
