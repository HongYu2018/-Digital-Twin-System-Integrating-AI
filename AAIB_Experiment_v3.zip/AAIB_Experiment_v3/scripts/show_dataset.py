"""Create an offline review page for draft options, labels and source quotes."""
from pathlib import Path
import json,html
ROOT=Path(__file__).resolve().parents[1];esc=html.escape
qs=[json.loads(s) for s in (ROOT/'data/aaib/selection_questions.jsonl').read_text(encoding='utf-8').splitlines()]
for split in ['dev','test']:
 cards=[]
 for q in qs:
  if q['split']!=split:continue
  opts=''.join('<li><b>'+esc(o['id'])+'</b> '+esc(o['text'])+(' <strong>[reference label: correct]</strong>' if o['id'] in q['correct_ids'] else ' [reference label: incorrect]')+'</li>' for o in q['choices'])
  quotes=''.join('<blockquote>'+esc(s['quote'])+'</blockquote><a href="'+esc(s['pdf_url'])+'#page='+str(s['pdf_pages'][0])+'">Original report, PDF page(s) '+str(s['pdf_pages'])+'</a>' for s in q['source_support'])
  cards.append('<article><h2>'+esc(q['id'])+'</h2><h3>'+esc(q['question'])+'</h3><ul>'+opts+'</ul>'+quotes+'</article>')
 out=ROOT/'review';out.mkdir(exist_ok=True);(out/(split+'_selection_labels.html')).write_text('<!doctype html><meta charset="utf-8"><title>AAIB draft labels</title><style>body{font:16px system-ui;max-width:1000px;margin:30px auto;background:#f2f5f8;color:#152f48;line-height:1.6}article{padding:25px;background:white;margin:20px 0}blockquote{border-left:4px solid #246681;padding-left:16px}</style><h1>'+split.upper()+' selection labels — AI-authored draft</h1><p>Labels are visible only on this review page and to the scorer, not in the model payload. Verify the original source and option interpretation. Do not use test outputs to select favorable questions.</p>'+''.join(cards),encoding='utf-8')
print('Review pages created.')
