from pathlib import Path
import sys,json,random,hashlib,collections
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scripts'))
from aihc.core import read_lines,write_lines,write_json
from distractors import DISTRACTORS
questions=read_lines(ROOT/'data/aaib/questions.jsonl');out=[]
unknown={2:['The investigation established the exact water route through a single identified floor opening.','The report established that no water reached the generator control units.'],7:['The investigation conclusively attributed the power loss to a specific fuel-system maintenance operation.','The investigation conclusively attributed the power loss to an identified crankshaft fracture.'],8:['The investigation precisely located the ice at a particular aileron cable pulley.','The investigation conclusively ruled out ice as the cause of the restriction.'],9:['Bearing removal was conclusively confirmed as the initiating cause.','The forensic assessment established a single initiating defect in the bearing.'],12:['A confirmed engine defect limiting power was established as the cause.','A confirmed carburettor failure was established as the cause of inadequate climb.'],17:['The failed 1PA contactor was conclusively proven to initiate the power loss.','Replacing several components conclusively established the initiating component.']}
cross={'cross-001':['Both reports established the exact water route or ice location.','G-ONEE conclusively excluded water ingress while G-DHLS pinpointed the ice location.'],'cross-002':['Both investigations conclusively established fuel-system maintenance as the cause.','G-TOMX established water in the carburettor as the cause, while N4698W remained entirely unexplained.']}
for q in questions:
 if q['id'].startswith('cross-'):bad=cross[q['id']]
 else:
  rid=int(q['id'].split('-')[1]);tag=q['id'].split('-')[2]
  bad=unknown[rid] if tag.startswith('u') else DISTRACTORS[rid][int(tag[1:])-1]
 gold=q['gold_claims'] if q['answerable'] else [q['reference_answer']]
 candidates=[(text,True) for text in gold]+[(text,False) for text in bad]
 seed=int(hashlib.sha256(('selection-v1|'+q['id']).encode()).hexdigest()[:16],16);random.Random(seed).shuffle(candidates)
 choices=[{'id':chr(65+i),'text':t} for i,(t,_) in enumerate(candidates)];goldids=[chr(65+i) for i,(_,correct) in enumerate(candidates) if correct]
 assert len({c['text'] for c in choices})==len(choices) and set(goldids)<{c['id'] for c in choices}
 out.append({**q,'open_question_answerable':q['answerable'],'task_mode':'source_supported_claim_selection','choices':choices,'correct_ids':goldids,'label_status':'AI_AUTHORED_SOURCE_CHECKED_DRAFT','distractor_rationale':'Incorrect alternatives contradict the cited reference finding, reverse a reported uncertainty, or substitute an incorrect event/value; full source/expert verification remains pending.'})
write_lines(ROOT/'data/aaib/selection_questions.jsonl',out)
write_json(ROOT/'data/aaib/selection_manifest.json',{'questions':len(out),'splits':dict(collections.Counter(q['split'] for q in out)),'correct_options':sum(len(q['correct_ids']) for q in out),'incorrect_options':sum(len(q['choices'])-len(q['correct_ids']) for q in out),'version':'selection-v1','authoring':'Authored without seeing selection-task model outputs. Selection task differs from open-ended QA. Test source texts were seen by dataset author.'})
print('Selection dataset:',len(out),'items')
