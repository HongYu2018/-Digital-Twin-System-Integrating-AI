$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
python experiment.py check
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python experiment.py freeze
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
if (-not (Test-Path 'work/index-all/index.json')) {
    python experiment.py build --scope all
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
python experiment.py run --split test --task open --out work/test-open-v2
exit $LASTEXITCODE
