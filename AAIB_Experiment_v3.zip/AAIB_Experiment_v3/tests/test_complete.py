import unittest,sys,tempfile,contextlib,io
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import experiment as e
from aihc.chunk_graph import links,retrieve
class Tests(unittest.TestCase):
 def test_dataset(self):
  with contextlib.redirect_stdout(io.StringIO()):r=e.audit_data()
  self.assertEqual(r['questions'],80);self.assertEqual(r['reports'],18)
 def test_metrics(self):
  self.assertEqual(e.prf(0,0,2),[0,0,0]);self.assertEqual(e.prf(2,1,1),[2/3]*3)
 def test_selection_invalid(self):
  opts=[{'id':'A'},{'id':'B'}]
  for value in [['A','A'],['C'],[1]]:
   with self.assertRaises(ValueError):e.selection_result({'selected_ids':value},opts)
 def test_graph_and_semantic_seeds(self):
  chunks=[{'id':str(i),'doc_id':'d','word_start':i*200,'text':'bearing'} for i in range(4)];triples=[{'chunk_id':str(i),'subject':'duplex bearing','object':'actuator'} for i in [0,3]]
  edges=links(chunks,triples);self.assertTrue(any(x['relation']=='SAME_ENTITY' and x['source']=='0' and x['target']=='3' for x in edges));self.assertEqual(sum(x['relation']=='NEXT' for x in edges),3)
  idx={'chunks':chunks,'vectors':[[1,0],[.9,.1],[.1,1],[.5,.5]],'chunk_links':edges};out=retrieve(idx,[1,0],3,True);self.assertEqual([x['id'] for x in out[:2]],['0','1'])
 def test_freeze_detects_changed_inputs(self):
  with tempfile.TemporaryDirectory() as t,patch.object(e,'ROOT',Path(t)),patch.object(e,'fingerprint',return_value={'version':1}),contextlib.redirect_stdout(io.StringIO()):
   (Path(t)/'configs').mkdir();e.freeze();e.freeze()
   with patch.object(e,'fingerprint',return_value={'version':2}):
    with self.assertRaises(ValueError):e.freeze()
 def test_reuse_index_preserves_vectors_checks_scope(self):
  cfg=e.config();docs=e.corpus('dev');chunks=e.prepare_chunks(docs,cfg)
  idx={'config':cfg,'corpus_hash':e.digest(docs),'chunks':chunks,'vectors':[[1,0] for _ in chunks],'triples':[]};idx['index_hash']=e.digest(idx)
  with tempfile.TemporaryDirectory() as t,contextlib.redirect_stdout(io.StringIO()):
   source=Path(t)/'source.json';out=Path(t)/'out';e.write_json(source,idx)
   args=SimpleNamespace(scope='dev',out=str(out),reuse_index=str(source));e.build(args)
   result=e.read_json(out/'index.json');self.assertEqual(result['vectors'],idx['vectors']);self.assertGreater(len(result['chunk_links']),0);e.build(args)
   args.scope='all'
   with self.assertRaises(ValueError):e.build(args)
 def test_mock_run_resume_score_no_gold_payload(self):
  cfg=e.config();chunks=e.prepare_chunks(e.corpus('dev'),cfg);identity={'backend':'ollama','embedding_model':{'name':'nomic-embed-text:latest','digest':'TEST'},'generation_model':{'name':'qwen2.5:7b','digest':'TEST'}}
  idx={'config':cfg,'corpus_hash':e.digest(e.corpus('dev')),'chunks':chunks,'vectors':[[1,0] for _ in chunks],'triples':[],'chunk_links':links(chunks,[]),'backend_identity':identity};idx['index_hash']=e.digest(idx);requests=[];case=self
  class FakeBackend:
   def __init__(self,c):self.identity=identity;self.calls=[]
   def embed(self,texts,role='document'):return [[1,0] for _ in texts]
   def http(self,endpoint,payload):
    request=e.json.loads(payload['messages'][1]['content']);case.assertNotIn('correct_ids',request);case.assertNotIn('gold_claims',request);case.assertNotIn('source_support',request);requests.append(request)
    return {'message':{'content':'{"selected_ids":["A"]}'},'eval_count':10}
  with tempfile.TemporaryDirectory() as t:
   index=Path(t)/'index';index.mkdir();e.write_json(index/'index.json',idx);out=Path(t)/'run';args=SimpleNamespace(model=None,repeats=None,split='dev',task='selection',index=str(index),out=str(out),smoke=True)
   with patch.object(e,'Backend',FakeBackend),contextlib.redirect_stdout(io.StringIO()):
    e.run(args);self.assertEqual(len(requests),12);e.run(args);self.assertEqual(len(requests),12);e.score(SimpleNamespace(run=str(out)))
   result=e.read_json(out/'scores/results.json');self.assertEqual(result['status'],'SMOKE_TEST_NOT_SCIENTIFIC_RESULT');self.assertEqual(len(result['conditions']),6)
   rows=e.read_lines(out/'answers.jsonl');rows[0]['error']='simulated parse failure';rows[0]['selected_ids']=[];e.write_lines(out/'answers.jsonl',rows)
   with contextlib.redirect_stdout(io.StringIO()):e.score(SimpleNamespace(run=str(out)))
   result=e.read_json(out/'scores/results.json');self.assertEqual(sum(r['failures'] for r in result['conditions']),1)
if __name__=='__main__':unittest.main()
