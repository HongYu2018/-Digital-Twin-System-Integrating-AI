import unittest,sys,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from aihc.chunk_graph import retrieve
from aihc.context_guard import context_check

class PreservedExpansion(unittest.TestCase):
 def index(self):
  chunks=[{'id':str(i),'doc_id':'d','word_start':i*10,'text':'possible contributory fault '+str(i)} for i in range(10)]
  edges=[{'source':a,'target':b,'relation':'NEXT','entities':[]} for a,b in [('0','7'),('7','8'),('1','6'),('4','9'),('2','7'),('0','1'),('0','7')]]
  return {'chunks':chunks,'vectors':[[1,i/10] for i in range(10)],'chunk_links':edges}
 def test_keep_five_expand_three_only_one_hop(self):
  idx=self.index();out=retrieve(idx,[1,0],5,True)
  self.assertEqual([c['id'] for c in out],['0','1','2','3','4','6','7'])
  self.assertEqual([c['id'] for c in retrieve(idx,[1,0],5)],['0','1','2','3','4'])
  self.assertEqual(len(out[-1]['paths']),2)
  self.assertEqual(out[-1]['retrieval_role'],'one_hop_neighbour')
 def test_guidance_and_edge_order_cannot_rerank(self):
  idx=self.index();expected=retrieve(idx,[1,0],5,True)
  idx['chunk_links'].reverse()
  actual=retrieve(idx,[1,0],5,True,[{'id':'m-update-001'},{'id':'m-update-002'}],'cause contributory',1.0)
  self.assertEqual(actual,expected)
 def test_small_corpus_and_bad_graph(self):
  idx=self.index();idx['chunks']=idx['chunks'][:2];idx['vectors']=idx['vectors'][:2];idx['chunk_links']=[]
  self.assertEqual(len(retrieve(idx,[1,0],5,True)),2)
  idx['chunk_links']=[{'source':'0','target':'unknown','relation':'NEXT'}]
  with self.assertRaises(ValueError):retrieve(idx,[1,0],5,True)
 def test_budget_does_not_mutate_or_truncate(self):
  payload={'evidence':[{'id':'x','text':'one two three four'}],'guidance':['keep causal uncertainty']};original=copy.deepcopy(payload)
  cfg={'context_words':5,'num_ctx':16384,'num_predict':1536}
  self.assertFalse(context_check(payload,'prompt',cfg,{})['fits']);self.assertEqual(payload,original)
  cfg['context_words']=10
  self.assertTrue(context_check(payload,'prompt',cfg,{})['fits'])
  cfg['num_ctx']=100
  self.assertFalse(context_check(payload,'prompt',cfg,{})['fits'])

 def test_preflight_never_generates_and_cannot_be_scored(self):
  import experiment as e
  import tempfile,contextlib,io
  from types import SimpleNamespace
  from unittest.mock import patch
  cfg=e.config();chunks=e.prepare_chunks(e.corpus('dev'),cfg);identity={'embedding_model':{'digest':'MOCK'}}
  idx={'config':cfg,'corpus_hash':e.digest(e.corpus('dev')),'chunks':chunks,'vectors':[[1,0] for _ in chunks],'triples':[],'chunk_links':[],'backend_identity':identity};idx['index_hash']=e.digest(idx)
  class Backend:
   def __init__(self,cfg):self.identity=identity;self.calls=[]
   def embed(self,texts,role='document'):return [[1,0] for _ in texts]
   def http(self,*args):raise AssertionError('Preflight must not call chat')
  with tempfile.TemporaryDirectory() as t,patch.object(e,'Backend',Backend),contextlib.redirect_stdout(io.StringIO()):
   index=Path(t)/'index';index.mkdir();e.write_json(index/'index.json',idx);out=Path(t)/'preflight'
   e.run(SimpleNamespace(split='dev',model=None,repeats=None,index=str(index),out=str(out),task='open',smoke=True,preflight=True))
   summary=e.read_json(out/'preflight_summary.json');self.assertEqual(summary['jobs'],12);self.assertFalse(summary['generation_performed'])
   rows=e.read_lines(out/'answers.jsonl');by={c['id']:c for c in chunks}
   self.assertTrue(all(r['status']=='PREFLIGHT_ONLY' for r in rows))
   self.assertTrue(all(c['text']==by[c['id']]['text'] for r in rows for c in r['evidence']))
   with self.assertRaises(ValueError):e.score(SimpleNamespace(run=str(out)))

if __name__=='__main__':unittest.main()
