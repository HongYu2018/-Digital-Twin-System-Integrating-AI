import unittest,sys,tempfile,contextlib,io
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import experiment as e
from aihc.attribution import scoped_index,memory_applicable,evidence_checks,registrations
class AttributionTests(unittest.TestCase):
 def test_scope_and_missing_targets(self):
  chunks=[{'id':'a','doc_id':'a','word_start':0,'text':'Registration: G-ABCD Synopsis This report compares G-EFGH.'},{'id':'b','doc_id':'b','word_start':0,'text':'Registration: G-EFGH Synopsis This is another incident.'}]
  idx={'chunks':chunks,'vectors':[[1,0],[0,1]],'chunk_links':[{'source':'a','target':'b'}]}
  sub,meta=scoped_index(idx,'Why did G-ABCD turn?');self.assertEqual([c['id'] for c in sub['chunks']],['a']);self.assertEqual(sub['chunk_links'],[])
  sub,meta=scoped_index(idx,'Compare G-ABCD and G-EFGH');self.assertEqual(len(sub['chunks']),2)
  sub,meta=scoped_index(idx,'Compare G-ABCD and G-IJKL');self.assertFalse(meta['scope_applied']);self.assertEqual(len(sub['chunks']),2)
  self.assertIn('9H-LWB',registrations('9H-LWB'))
 def test_memory_task_not_keyword(self):
  one={'stage':'update','id':'m-update-001'};two={'stage':'update','id':'m-update-002'};ctx=[{'text':'The backup contactor could mask recurrence.'}]
  self.assertFalse(memory_applicable(two,'Which assemblies were replaced?',ctx))
  self.assertFalse(memory_applicable(one,'How was the failed bearing detected?',ctx))
  self.assertTrue(memory_applicable(two,'Which component conclusively initiated the power loss?',ctx))
  self.assertTrue(memory_applicable(one,'Why could the initiating cause not be determined?',[]))
 def test_quote_diagnostic_is_not_entailment(self):
  result={'evidence_checks':[{'claim':'x','source_id':'a','quote':'actual text'},{'claim':'x','source_id':'b','quote':'invented'}]}
  out=evidence_checks(result,[{'id':'a','text':'The actual text is here.'}]);self.assertTrue(out[0]['quote_present']);self.assertFalse(out[1]['source_supplied'])
 def test_open_run_payload_and_checks(self):
  cfg=e.config();chunks=e.prepare_chunks(e.corpus('dev'),cfg);identity={'embedding_model':{'digest':'TEST'}}
  idx={'config':cfg,'corpus_hash':e.digest(e.corpus('dev')),'chunks':chunks,'vectors':[[1,0] for _ in chunks],'triples':[],'chunk_links':[],'backend_identity':identity};idx['index_hash']=e.digest(idx);case=self
  class Fake:
   def __init__(self,c):self.identity=identity;self.calls=[]
   def embed(self,texts,role='document'):return [[1,0] for t in texts]
   def http(self,endpoint,payload):
    data=e.json.loads(payload['messages'][1]['content']);case.assertNotIn('gold_claims',data);case.assertNotIn('source_support',data)
    if data['evidence']:
     case.assertTrue(all(x['report_id']=='aaib-001' for x in data['evidence']));x=data['evidence'][0];checks=[{'claim':'test','source_id':x['id'],'quote':x['text'][:30]}]
    else:checks=[]
    return {'message':{'content':e.json.dumps({'evidence_checks':checks,'answer':'test','citations':[checks[0]['source_id']] if checks else []})}}
  with tempfile.TemporaryDirectory() as t,patch.object(e,'Backend',Fake),contextlib.redirect_stdout(io.StringIO()):
   path=Path(t)/'idx';path.mkdir();e.write_json(path/'index.json',idx);out=Path(t)/'run'
   e.run(SimpleNamespace(split='dev',model=None,repeats=None,index=str(path),out=str(out),task='open',smoke=True))
   rows=e.read_lines(out/'answers.jsonl');self.assertEqual(len(rows),12);self.assertFalse(any(r['error'] for r in rows));self.assertTrue(all(x['quote_present'] for r in rows for x in r['evidence_checks']))
