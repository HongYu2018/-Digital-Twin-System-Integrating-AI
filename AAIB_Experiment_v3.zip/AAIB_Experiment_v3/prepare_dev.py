"""Windows-friendly index reuse and retrieval-only preflight. No answer generation."""
import json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
index=root/'work/index-dev/index.json'
if not index.exists():
    source=input('Paste the full path to your EXISTING development index.json (or its folder): ').strip().strip('"').strip("'")
    path=Path(source)
    if path.is_dir():path=path/'index.json'
    if not path.is_file():raise SystemExit('Index not found. No files changed. Run again with the correct path.')
    subprocess.run([sys.executable,str(root/'experiment.py'),'build','--scope','dev','--reuse-index',str(path)],cwd=root,check=True)
subprocess.run([sys.executable,str(root/'experiment.py'),'run','--split','dev','--task','open','--preflight','--out',str(root/'work/dev-preflight-v3')],cwd=root,check=True)
summary=json.loads((root/'work/dev-preflight-v3/preflight_summary.json').read_text(encoding='utf-8'))
print('Preflight complete. No answers generated. Blocked payloads:',summary['blocked'])
print('ZIP and return this folder:',root/'work/dev-preflight-v3')
