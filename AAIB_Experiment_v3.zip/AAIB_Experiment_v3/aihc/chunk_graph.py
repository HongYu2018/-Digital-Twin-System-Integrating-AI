"""Vector-first retrieval over vectorized chunks, with explicit chunk-to-chunk links."""
import collections,math,re
from .core import cosine

def normalize(s):return ' '.join(re.findall(r'\w+',s.casefold()))
def links(chunks,triples):
 bydoc=collections.defaultdict(list);edges={}
 def add(a,b,relation,entity=None):
  if a==b:return
  key=(min(a,b),max(a,b),relation)
  if key not in edges:edges[key]={'source':key[0],'target':key[1],'relation':relation,'entities':[]}
  if entity and entity not in edges[key]['entities']:edges[key]['entities'].append(entity)
 for c in chunks:bydoc[c['doc_id']].append(c)
 for group in bydoc.values():
  group.sort(key=lambda c:c['word_start'])
  for a,b in zip(group,group[1:]):add(a['id'],b['id'],'NEXT')
 entity_chunks=collections.defaultdict(set)
 for t in triples:
  for name in [t['subject'],t['object']]:
   key=normalize(name)
   if len(key)>=4 and key not in {'aircraft','pilot','crew','flight','report','engine','investigation','the aircraft','the pilot'}:entity_chunks[key].add(t['chunk_id'])
 valid={c['id'] for c in chunks}
 for entity,ids in sorted(entity_chunks.items()):
  ids=sorted(ids & valid)
  # Broad hubs carry little discriminative information; preserve counts in report instead.
  if 2<=len(ids)<=12:
   for i,a in enumerate(ids):
    for b in ids[i+1:]:add(a,b,'SAME_ENTITY',entity)
 return sorted(edges.values(),key=lambda e:(e['source'],e['target'],e['relation']))

def retrieve(index,qvec,k=5,graph=False,memory=None,query='',weight=None):
 """Preserve vector top-k, then append one-hop neighbours of its first three.
 memory/query/weight retained for call compatibility; none influences retrieval.
 Neighbour order is stable chunk-ID order, not relevance reranking.
 """
 chunks=index['chunks'];vectors=index['vectors']
 if len(chunks)!=len(vectors):raise ValueError('Chunk/vector count mismatch')
 by={c['id']:c for c in chunks}
 if len(by)!=len(chunks):raise ValueError('Duplicate chunk IDs')
 if k<1:raise ValueError('k must be positive')
 scores={c['id']:cosine(qvec,v) for c,v in zip(chunks,vectors)}
 ranked=sorted(by,key=lambda cid:(-scores[cid],cid));initial=ranked[:k]
 seeds=set(initial[:3]);paths=collections.defaultdict(list)
 if graph:
  for edge in index['chunk_links']:
   a,b=edge['source'],edge['target']
   if a not in by or b not in by:raise ValueError('Graph edge endpoint absent from scoped index')
   for origin,target in [(a,b),(b,a)]:
    if origin in seeds and target not in initial:
     path={'from':origin,'to':target,'relation':edge['relation'],'entities':edge.get('entities',[])}
     if path not in paths[target]:paths[target].append(path)
 selected=initial+sorted(paths)
 return [{**by[cid],'score':(scores[cid]+1)/2,'vector_cosine':scores[cid],
          'retrieval_role':'vector_top5' if cid in initial else 'one_hop_neighbour',
          'vector_rank':ranked.index(cid)+1,'paths':sorted(paths[cid],key=lambda p:(p['from'],p['relation'],str(p['entities'])))}
         for cid in selected]
