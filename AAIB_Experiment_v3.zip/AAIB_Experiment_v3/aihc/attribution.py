"""Source metadata and task cues only: never consumes benchmark reference labels."""
import re
REG=r'(?<![A-Z0-9])(?:[A-Z0-9]{1,2}-[A-Z0-9]{3,5}|N[0-9]{1,5}[A-Z]{0,2})(?![A-Z0-9])'
def registrations(text):return sorted(set(re.findall(REG,text.upper())))
def scoped_index(index,question):
 targets=registrations(question);first={}
 for c in index['chunks']:
  if c['doc_id'] not in first or c['word_start']<first[c['doc_id']]['word_start']:first[c['doc_id']]=c
 # Restrict to header, avoiding references to other incidents later in the report.
 primary={d:registrations(c['text'].split('History of the flight')[0].split('Synopsis')[0][:1000]) for d,c in first.items()}
 matched={d for d,regs in primary.items() if set(regs)&set(targets)}
 # Scope only if EVERY named registration has a matching report header.
 resolved=set(x for d in matched for x in primary[d])
 active=bool(targets) and set(targets)<=resolved
 keep=[i for i,c in enumerate(index['chunks']) if not active or c['doc_id'] in matched]
 ids={index['chunks'][i]['id'] for i in keep}
 subset={**index,'chunks':[index['chunks'][i] for i in keep],'vectors':[index['vectors'][i] for i in keep],'chunk_links':[e for e in index['chunk_links'] if e['source'] in ids and e['target'] in ids]}
 return subset,{'query_registrations':targets,'scope_applied':active,'report_ids':sorted(matched) if active else sorted(first),'report_primary_registrations':primary}
def memory_applicable(memory,question,preliminary):
 if memory['stage']=='initial':return True
 q=question.lower();causal=bool(re.search(r'\b(caus\w*|why|initiat\w*|contribut\w*|explan\w*|explain\w*|prove\w*|conclusive\w*|determin\w*)\b',q))
 # A mechanical detection/replacement query is not a causal inference task.
 if not causal:return False
 if memory['id']=='m-update-001':return True
 if memory['id']=='m-update-002':
  text=q+' '+' '.join(c['text'].lower() for c in preliminary)
  return bool(re.search(r'\b(backup|back-up|protective|redundan\w*|mask\w*|recurr\w*|reoccurr\w*)\b',text))
 return False
def evidence_checks(result,evidence):
 """Quote identity diagnostics only; does NOT prove semantic entailment."""
 by={c['id']:c['text'] for c in evidence};out=[]
 for c in result.get('evidence_checks',[]):
  sid=c.get('source_id','');quote=c.get('quote','');out.append({'source_id':sid,'claim':c.get('claim',''),'quote':quote,'source_supplied':sid in by,'quote_present':bool(quote) and sid in by and quote in by[sid]})
 return out
