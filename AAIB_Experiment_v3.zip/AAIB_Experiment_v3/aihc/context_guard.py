"""Keep complete retrieved evidence. Never silently slice or drop chunks."""
import json

def context_check(payload,prompt,cfg,schema):
 words=sum(len(e['text'].split()) for e in payload['evidence'])+sum(len(g.split()) for g in payload['guidance'])
 # Conservative byte-based screen, not a model-specific tokenizer. Reserve
 # output tokens and 1,024 tokens for templates/schema/runtime overhead.
 encoded=json.dumps(payload,ensure_ascii=False,separators=(',',':'))
 screen=len((prompt+encoded+json.dumps(schema)).encode('utf-8'))+cfg['num_predict']+1024
 return {'evidence_and_guidance_words':words,'word_limit':cfg['context_words'],
         'conservative_token_screen':screen,'num_ctx':cfg['num_ctx'],
         'fits':words<=cfg['context_words'] and screen<=cfg['num_ctx'],
         'policy':'No application truncation; oversized payload blocked before chat. Byte screen is not exact tokenization.'}
