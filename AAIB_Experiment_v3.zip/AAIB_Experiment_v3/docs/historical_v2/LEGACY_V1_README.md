# AAIB complete revision experiment

Prepared 22 September 2026. This is a reconstruction for the journal revision, not the transferred industrial implementation. Extract this ZIP into a NEW folder and keep your earlier runs unchanged.

## What is included

- Extracted text and source metadata for 18 public AAIB field reports; 80 source-supported questions: 22 development and 58 test.
- A vector index for every chunk, vector-first retrieval, explicit chunk relationships, static/updated draft CLKM, and six controlled configurations.
- Checkpointed construction and resumable generation with Ollama, exact claim-selection scoring, ablation tables, paired comparisons, and provenance logs.
- An optional open-answer task, source/label review pages, and tests. Python standard library only; no pip installation is required for running the experiments.

**There are no pre-filled model performance results.** Run Ollama on your computer to generate them. Verification used mocked model calls; it does not establish model accuracy or Windows/GPU performance.

## Important task distinction

The default task asks the model to select all correct statements from supplied alternatives. Precision, recall and F1 are calculated directly from selected option IDs and reference IDs: no LLM judge and no per-response human scoring are required.

This is **structured claim selection**, not free-text question answering. The labels and distractors are AI-authored drafts with linked source passages, not expert-validated ground truth. Automatic calculation eliminates judge-format failures, but cannot establish that every reference label is right. Do not relabel these scores as free-text answer factuality or evidence of human collaboration. See `docs/PROTOCOL.md`.

## Tomorrow morning: run development

Open PowerShell in the extracted folder containing `experiment.py`. Ollama must be running. Your existing `qwen2.5:7b` and `nomic-embed-text` models are the defaults.

```powershell
python experiment.py check
python -m unittest discover -s tests -v
python experiment.py build --scope dev
python experiment.py run --split dev
python experiment.py score --run work/dev-selection
```

Alternatively, ` .\run_development.ps1 ` runs check/build/run/score. If PowerShell blocks scripts, use the individual Python commands above; no policy change is needed. Index construction can take time and prints progress. Rerun the same build command after an interruption to resume cached chunks.

The full default development run produces **132 responses: 22 questions × six configurations**. Resume missing responses with the same `run` command. Completed failures are retained and scored as empty predictions; rerunning does not silently replace them.

For a quick model connection check after building:

```powershell
python experiment.py run --split dev --smoke
python experiment.py score --run work/dev-selection-smoke
```

This creates 12 responses in a separate folder. Its table is marked as a smoke test and is not research evidence.

## Reuse your completed development index

You do not have to rebuild its embeddings and extracted triples if the corpus and settings match. Copy your OLD `work/aaib-dev-index` folder into this new package as `work/legacy-dev-index`, then use this INSTEAD of the normal development build:

```powershell
python experiment.py build --scope dev --reuse-index work/legacy-dev-index
```

The command checks hashes and embedding/chunk settings, retains the vectors/triples and adds explicit chunk-to-chunk relationships. If your old index has another name, pass that folder. A mismatch stops safely. The new structured task needs new model responses; old free-text responses cannot be converted into choice predictions. Keep those old outputs for diagnostics and possible separate semantic assessment.

## Where the results appear

After `score`, open:

- `work/dev-selection/scores/ablation_table.md` — readable six-row table.
- `work/dev-selection/scores/ablation_table.csv` — macro/micro precision, recall, F1, exact match, failures, latency and source-report coverage.
- `paired_comparisons.csv` — paired F1 differences with exploratory incident-cluster intervals.
- `per_response.csv`, `task_breakdown.csv`, `results.json` — traceable detailed outputs.

Every response retains the supplied evidence, graph links, memory IDs, choices, selected IDs and raw Ollama response. `manifest.json` records prompts, configuration, model digests and hashes. Do not edit output files to improve the scores. A full-system win is a hypothesis; ties and losses must also be reported.

## Run the test split after development choices are settled

Review `review/dev_selection_labels.html` and `review/test_selection_labels.html` in a browser to inspect source support and the draft options. They are reference-inspection pages, not a claim that expert review has occurred. If labels need correction, edit the source specification/data consistently before freezing; keep a dated change log. Do not tune using test model performance.

```powershell
python experiment.py freeze
python experiment.py build --scope all
python experiment.py run --split test
python experiment.py score --run work/test-selection
```

Or use `.\run_test.ps1`. This freezes current inputs, builds the full 505-chunk corpus and generates **348 test responses: 58 questions × six configurations**. Default scoring is automatic. A freeze is a provenance record, not human approval or preregistration. The full build has its own checkpoints; it currently rebuilds development chunks too.

Model, repeats and retrieval settings are in `configs/experiment.json`. Set them before freezing. A changed configuration cannot resume into an existing run folder. Use a separate experimental copy/folder and document changes if a new experiment is necessary. Do not erase an old freeze to conceal test-informed changes.

## Optional free-text answers

```powershell
python experiment.py run --split dev --task open
```

This saves responses in `work/dev-open`. The exact scorer intentionally does not score free-text answers. `scripts/check_judge.py --help` exposes a small optional semantic-judge diagnostic; passing it is not sufficient validation for publication. The old judging errors included semantic errors even when JSON was valid.

## Troubleshooting

- Connection refused: start Ollama, then rerun the same command.
- Missing model: run `ollama pull qwen2.5:7b` / `ollama pull nomic-embed-text` as needed.
- GPU memory/timeout: close other model workloads. Change settings only in a new run/configuration and preserve the old run. The default 8192-token context still needs a local hardware check.
- Dataset/model/index hash mismatch: do not disable the check. Use the matching files or a fresh output folder/index.
- Interrupted JSONL write: preserve the file first; a truncated final record needs inspection rather than deleting arbitrary failed rows.
- Completed generation failures: retained as zero-credit predictions with a failure count. Investigate repeated failures before drawing conclusions; don't omit hard cases.

Read `docs/PROTOCOL.md`, `docs/REVISION_SCOPE.md` and `NOTICE.md` before using results in the revised manuscript. The experiment runs on your computer while it is awake; this download does not remotely start Ollama.
