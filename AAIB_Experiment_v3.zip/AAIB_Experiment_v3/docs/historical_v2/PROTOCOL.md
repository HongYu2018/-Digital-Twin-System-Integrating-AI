# Experimental protocol — reconstruction v1

## Purpose and status

Test whether vector retrieval with explicit chunk relationships and development-derived updated CLKM improves a structured incident-report claim-selection task relative to controlled baselines. This is a new reconstruction, not replication of the unavailable original deployment. No outcome is guaranteed. Default labels, graph extraction and CLKM are drafts, not expert-approved artifacts.

Primary contrast: updated CLKM full system minus vector RAG in macro F1 on the fixed test split. Secondary contrasts isolate graph addition, static guidance, memory updates, and the graph/reranking bundle relative to matched guidance. Report all six rows and every prespecified contrast, including negative results. The small benchmark and draft labels make outcomes exploratory.

## Corpus and sampling

The included snapshot contains 18 AAIB field reports selected from the first 50 entries in a GOV.UK catalogue query ordered by descending publication timestamp, retrieved 22 September 2026. `source_metadata/search_snapshot.json`, `selection_log.json`, `manifest.json` and per-report metadata preserve the selection and source URLs. This is a convenience sample, not a random or representative sample of aviation incidents. It does not support operational maintenance generalization.

`source_text/` holds extracted text. `data/aaib/corpus.jsonl` is the normalized corpus; `corpus_dev.jsonl` is its development subset. The supplied extracted text, rather than re-extraction with a different PDF tool, is the canonical experimental input. Original PDF URLs and hashes are recorded. `scripts/download_sources.py` can retrieve original PDFs for source inspection; its downloads require internet access. Original PDF images are not bundled. See NOTICE for attribution and exclusions.

Development: reports aaib-001, 005, 009, 013 and 017, five incident groups, 148 chunks and 22 questions. Test: remaining 13 reports, 11 incident groups and 58 questions; aaib-002/008 and aaib-007/014 are grouped because of shared/cross-report questions. Incident groups do not straddle the question split. The full retrieval corpus has 505 chunks from all 18 reports. Test questions deliberately retrieve their corresponding test reports: these are evidence-retrieval tasks, not unseen-document generalization. Query labels and reference answers are never sent to the model or retriever.

The 80 questions include 72 single-report questions, six original open-QA unanswerable questions and two cross-report questions. Question files contain report/page pointers, exact quotes and character offsets. Integrity checks validate that quoted spans exist; this is not semantic adjudication of answers.

## Structured task and reference labels

`selection_questions.jsonl` supplies each question with candidate statements. Correct statements derive from its original reference claims; two incorrect alternatives are authored per question. Choices are deterministically shuffled using the question ID and assigned option IDs. The model selects all and only correct options; it may select none. The same alternatives are supplied to every configuration. Retrieval embeds the question only, not the choices.

For the six originally unanswerable questions, the correct option expresses the limitation in the source. Thus all structured questions have at least one correct option. Their legacy task category may still say `unanswerable`; these rows evaluate recognition of uncertainty, not open-QA abstention. No abstention metric is claimed for this mode.

The candidate statements and their labels are AI-authored, source-linked drafts. Wrong options are intentional distractors, not report assertions. Recognition can be easier than generation, and wording/length/negation cues can reveal an option. An independent source-based label review and stronger distractors would improve validity; obtaining such review is separate from rating all 348 model responses. The shipped HTML pages facilitate this review. They do not record or imply expert approval. All claims about measured accuracy are conditional on label correctness.

## Six configurations

| Key | Vector evidence | Chunk links | Guidance |
|---|---|---|---|
| llm_only | None | None | None |
| vector_rag | Top-k cosine | None | None |
| kg_rag | Vector first, graph expansion/reranking | NEXT / SAME_ENTITY | None |
| clkm_static | Same hybrid retrieval | Same | Initial CLKM |
| clkm_updated | Hybrid plus memory evidence-type bonus | Same | Initial + updated CLKM |
| vector_notes | Top-k cosine | None | Same selected updated guidance as full |

`kg_rag` is shorthand for **vector RAG plus chunk KG**, not graph-only retrieval. The last control tests the full graph/reranking bundle beyond adding the same guidance text. The full vs static contrast combines updated instructions and their retrieval bonus; it cannot separately attribute those two effects. Vector/graph conditions may retrieve different content while sharing a context cap. Effective evidence length can differ because guidance occupies part of that cap.

## Chunking, embeddings and graph

Whitespace chunks have 250 words with 40-word overlap. This is fixed-window chunking, not the original paper's semantic chunking. Default embedding is Ollama `nomic-embed-text`, with document prefix `search_document: ` and query prefix `search_query: `. Exact installed model digests are recorded; tags alone are insufficient identifiers. Vectors remain stored for every chunk.

The graph builder uses `prompts/graph.txt` and the configured generation model to propose subject/relation/object triples with evidence quotes. Validation requires verbatim grounding, valid endpoints and allowed relations. This rejects malformed or ungrounded candidates but does not prove their semantic correctness. Review CSVs preserve accepted and rejected extractions. Candidate status is explicit.

Chunk links are undirected adjacency (`NEXT`) within a report and shared normalized subject/object entity (`SAME_ENTITY`). Generic names are filtered; shared entities must span 2–12 chunks to avoid broad hubs. Entity-name equality is a simple heuristic, not validated entity resolution. Link construction code is `aihc/chunk_graph.py`. Extracted causal labels are not treated as established causal relations between chunks.

Vector cosine ranks all chunks. Hybrid retrieval starts with the top 12 vector candidates and adds all one-hop neighbors of the top three vector seeds. Graph support for a candidate is the maximum positive seed cosine times 0.35 for NEXT or 0.65 for SAME_ENTITY. With c = cosine and g = graph support, hybrid score is:

`0.85 * ((c + 1) / 2) + 0.15 * g + memory_bonus`.

The two strongest vector seeds are preserved; other positions are filled by hybrid rank, up to five chunks. A zero graph-support score does not remove a vector candidate. Selected edge descriptions are sent only when both endpoints are in the final evidence, capped at 24 edges. Full retrieval candidates, scores and paths are logged.

For updated CLKM, predefined development-derived rules can add 0.025 each for uncertainty or contributory-factor evidence when the corresponding memory is selected and the question matches causal/uncertainty wording. Rules inspect chunk text, never reference labels. The exact regular expressions are versioned in the code. This is a deterministic heuristic, not reinforcement learning.

## Memory and human-centred scope

One initial instruction and two updates derive solely from development references (aaib-001, 009 and 017). Lexical triggers establish eligibility; instruction embeddings rank eligible entries against the question, with up to three selected. Static memory uses the initial entry only. Updated and matched-guidance conditions can use all entries.

These are simulated offline memory stages authored from development references before the new runs. They are not observed expert interactions, learned updates or evidence that humans improved the deployed system. Legacy metadata fields `approved_by` explicitly contain `AI_DRAFT_NOT_EXPERT_APPROVED`; a date there is an authoring date, not an expert sign-off. No test-derived memory updates are allowed.

## Generation and reproducibility

Default model qwen2.5:7b, temperature 0, seed 42, one repeat, 8192-token context setting and 1024 maximum generated tokens. Additional repeats use seed 42 + repeat index. Runtime settings, prompt text and model digests are recorded in each manifest. Temperature zero and a seed do not guarantee bit-identical GPU execution.

A common prompt and JSON schema are used for all configurations. LLM-only may use existing knowledge and is not forced to refuse because no retrieval was supplied. The model receives only the question, choices, selected evidence, chunk links and guidance. Neither correct IDs, reference answers nor source-support annotations are supplied. References can still have appeared in model pretraining; this benchmark cannot establish absence of pretraining exposure.

Evidence plus guidance is limited to 1600 whitespace words. Choices, JSON markup, link metadata and the system prompt are additional context, so this is not a strict total-token budget. Ollama token counts are retained in raw responses. Inspect local context use during a smoke run. There is no reranking LLM. Jobs are deterministically shuffled to spread order effects. Construction is checkpointed; generation resumes missing IDs only. Changing identities/inputs requires a new output directory.

The test freeze records data, memory, configuration and code hashes. It is a local provenance safeguard, not externally timestamped preregistration. Test corpus graph construction is unsupervised with respect to question labels and is permitted, but test outcome-driven method selection must be disclosed. Contributors authoring the benchmark necessarily saw its source facts; it is not a blind external evaluation.

## Exact scoring

Scoring unit: an option-level factual statement within one question response. For predicted ID set S and correct ID set G:

- TP = size of S intersect G; FP = size of S minus G; FN = size of G minus S.
- Precision = TP / (TP + FP), recall = TP / (TP + FN).
- F1 = 2 TP / (2 TP + FP + FN).
- A zero denominator produces zero. G is nonempty for every structured item.

Macro metrics average the respective per-response values across the same questions and repeats. Micro metrics recompute from pooled TP/FP/FN. Macro F1 is not obtained from the harmonic mean of macro P/R. Under these definitions macro F1 cannot exceed both macro P and macro R. Exact match requires identical predicted and correct sets.

Unknown/duplicate choice IDs, malformed JSON or generation exceptions are failures. They receive an empty prediction, zero P/R/F1, all correct options counted as FN and an explicit failure flag. No successful-subset table is used. Scoring requires every expected run ID, so missing runs cannot quietly alter condition denominators. All conditions receive the same number of questions and repeats.

Source-report coverage counts the fraction of question-supporting report IDs represented in the supplied evidence. It is unavailable for LLM-only. It is a coarse diagnostic, **not chunk relevance precision/recall**, and does not prove the answer-bearing passage was retrieved. Latency is median per-job pipeline time, excluding up-front query/memory embeddings and index construction. Loading/cache/order effects remain; do not call this an end-to-end deployment speed comparison.

Paired comparisons average repeats per question, then use 2000 resamples of whole incident groups with replacement (seed 17); percentile endpoints approximate 95% intervals for macro-F1 differences. Only five development and 11 test clusters are available, so intervals are exploratory and can be unstable. Secondary comparisons are not multiplicity-adjusted. The task breakdown retains original question-type labels. Report means, intervals, counts and failures together.

## Optional open answers and judge diagnostics

`--task open` generates free-text answers and chunk citations with the same retrieval configurations. It does not receive choices. Exact choice scoring is unavailable for this task, and saved citations are not automatically proof of entailment. Human semantic assessment or a separately validated semantic judge is needed for free-text quality claims.

The optional judge diagnostic includes a small fixed set of entailment/contradiction/unknown controls. Passing controls is necessary evidence of basic functioning, not sufficient reliability on this dataset. Previous judge runs accepted semantically false matches even after format problems were repaired. Those results are not adopted as validated quality scores here.

## Reporting boundaries

Results can support limited comparisons on this structured retrospective benchmark if the labels are defensible. They do not establish improved open-answer factuality, human task time/trust/usability, autonomous memory learning, operational twin fidelity, industrial safety, or universal superiority. A stronger revision would separately validate a manageable source-label sample and/or conduct a small structured expert assessment, while narrowing unsupported claims. State exactly what was and was not evaluated.
