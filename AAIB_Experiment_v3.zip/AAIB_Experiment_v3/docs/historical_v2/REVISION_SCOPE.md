# Relationship to the manuscript and reviewer comments

Use the consistent abbreviation CLKM. This package operationalizes the clarified architecture: every chunk is embedded; vector similarity retrieves initial evidence; chunk relationships expand/rerank it; organizational memory supplies guidance and limited retrieval rules.

It does not recover the original deployed implementation or original Table 1 calculations. Do not describe new measurements as a reanalysis of unavailable original logs. Original numerical inconsistencies require correction or withdrawal rather than retroactive justification.

| Concern | What this package provides | Remaining limitation |
|---|---|---|
| C1 protocol and evidence | Explicit data, settings, scoring units, model digests, prompts, logs and fixed question split | Small convenience corpus, draft labels; structured selection differs from original QA |
| C2 inconsistent metrics | One exact set-scoring implementation with known-count tests, macro/micro outputs and failure denominators | Does not explain how original inconsistent values arose |
| C3 inadequate baselines | LLM-only, vector, vector + chunk graph, static/updated CLKM, matched-guidance control | Updated instruction and retrieval effects are bundled in full-vs-static |
| C4 human-centered evidence | Review aids and explicit scope boundaries | No user study, expert approval, task-time or collaboration outcome measured |
| C5 broad deployment claims | Retrospective incident-analysis experiment | Not a validated operational maintenance twin |
| C6 reproducibility | Runnable reconstruction, dataset, source links, prompts, configuration and test suite | Original code unavailable; local models must be run; public release still requires authors' decisions |
| C7 references | No automatic bibliography modifications | Authors must remove duplicate references and replace/justify vendor sources |
| C8 writing | Consistent labels and restrained experimental language in protocol | Full manuscript proofreading still needed |

## Implemented versus proposed mechanisms

Implemented: vectorized fixed-window chunks, adjacency/shared-entity graph, vector-first hybrid retrieval, static and simulated updated memory, traceable prompts/outputs, deterministic claim-selection scoring.

Not implemented or evaluated: original semantic chunking, reinforcement learning, continuously learned corporate memory, actual expert edits, production twin synchronization, live operational sensor integration, original enterprise UI, or organizational deployment outcomes. A graph path is retrieval context, not a causal explanation validated by an expert.

## Changes from previous local runs

The existing development index can supply identical vectors and source-grounded candidate triples. New explicit chunk links are added. Earlier free-text outputs remain useful for diagnosing retrieval and failure modes, but cannot be scored as if the model had selected statement IDs. The new selection experiment needs fresh generation. New manifests prevent accidental mixing.

Avoid claims such as “the full system is best” before evaluating. A result can show no improvement or poorer performance. Report such outcomes and interpret which contribution was supported. Do not tune test options, rules or memory to reverse an unfavorable result.

## Suggested reporting content after real runs

Describe the reconstruction openly, name the structured claim-selection task, give the exact question/report/incident counts, identify AI-authored labels and any subsequent review actually performed, report all six conditions with uncertainty and failures, and distinguish development from test results. Include an appendix or repository artifact manifest and disclose the alternative open-answer task if it is reported separately.

Do not present this file as a completed point-by-point response: actual measured results, any real expert review and revised manuscript locations still need to be inserted by the authors after the experiments.
