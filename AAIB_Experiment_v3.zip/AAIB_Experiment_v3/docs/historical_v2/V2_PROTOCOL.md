# Version-2 protocol addendum

This is a documented development revision following the semantic diagnosis of the 132 version-1 development answers. It does not use held-out model results, revise labels to obtain a desired ordering, or generate fabricated scores. Apply the same frozen semantic assessment to every configuration. Report positive, negative and null changes.

## Shared source scoping

Before retrieval, aircraft-registration patterns are extracted from the question and report headers. The first chunk of each report supplies header text, bounded before Synopsis/History and at 1,000 characters. If every named registration maps to a header, restrict all retrieval configurations to the union of those reports. Otherwise retain the corpus. Every retained chunk remains vectorized and ranked by vector similarity before any graph expansion. Chunk links are restricted to retained endpoints. This is metadata filtering; the vector baseline must be described as metadata-filtered vector RAG. It is not evidence of graph benefit by itself.

Patterns cover common hyphenated registrations and N-numbers, but are not universal aviation identifier parsers. Questions without an explicit recognized registration do not get this filter. Broader analytical questions can need other reports; header filtering is suited to this incident-specific question set and may reduce discovery outside it. An unresolved named incident falls back instead of being silently dropped.

## Attribution in generation

Evidence includes report_id, report_primary_registrations and registrations_mentioned_in_chunk. These are provenance cues, not authoritative labels assigning every sentence to an incident. Sections describing other incidents can continue across chunks without repeating a registration. The common prompt explicitly distinguishes report ownership from incident attribution, source uncertainty from missing context, and conflicting source statements from model mistakes.

All conditions receive the same revised prompt. The LLM-only condition receives no source evidence or memory and may use existing knowledge; its evidence-check/citation arrays should remain empty. Query registration names are derived solely from the question. Shared preprocessing still runs before each job, so logged pipeline_seconds is not a clean end-to-end speed advantage measurement for LLM-only.

## Memory selection

Initial memory is eligible for every task. An update first requires causal, explanation, initiating, contributory, proof or determination wording. Detection and replacement-list queries do not qualify merely because they mention a failed/replaced component. Update 001 handles causal evidence and uncertainty. Update 002 additionally requires backup/protective/redundancy/masking/recurrence cues in the question or preliminary top-five vector chunks. There is no incident-ID, question-ID or answer-specific rule.

Eligible memories use the same embedding ranking and three-entry cap. The preliminary evidence is computed once by the same vector retrieval path regardless of full versus matched-guidance condition. Thus full and vector-plus-guidance have the same memory eligibility; any difference thereafter comes from the graph/reranking context. This selection is still a heuristic, not a learned semantic classifier. Irrelevant preliminary text may trigger a rule, or missing evidence may prevent a relevant rule from being selected. Inspect actual selections rather than assuming success.

The two update instruction texts remain unchanged. The reconstruction still does not demonstrate human feedback, reinforcement learning, continuous learning or an operational corporate memory update process.

## Evidence-check response schema

The common open-answer schema requests evidence_checks, answer and citations. Each of up to four check records contains claim, source_id and short verbatim quote. This is a compact evidence record, not a model's private reasoning trace. The code logs whether the source was supplied and the quote exists. These checks establish identity only: an exact quote can concern another incident or fail to entail the claim. Invalid quotes/citations are retained as diagnostics; they do not trigger outcome-selective retries or silently rewrite the answer.

The same generation budget and schema apply to all six conditions. Extra records can consume output tokens, so truncation/failure counts need reporting. Runtime remains temperature zero, seed 42 + repeat, 8192 context and 1024 output-token limit unless explicitly changed in a separately versioned configuration. One generation per condition/question is the development default. All raw responses and evidence are saved. Reusing an index does not reuse answers.

## Interpretation

Comparisons within version 2 isolate the six configured architectural conditions under the shared changes. Version-1 versus version-2 differences reflect a bundle of common prompt, metadata and memory-selection changes; do not attribute the entire gain to CLKM or the graph. A stronger causal study could add further ablations after the development design is settled, but avoid repeated test-driven method selection.

Do not equate evidence-check validity with semantic accuracy. Use the same source-based meaning/causality/completeness rubric, disclose AI assessment and its lack of independent expert validation, retain uncertainty about borderline ratings, and preserve the source-conflict exclusion equally across conditions. Graph usefulness still requires semantic relevance judgements; report-association counts do not substitute for them.
