$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
python experiment.py check
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
if (-not (Test-Path 'work/index-dev/index.json')) {
    Write-Host 'Build or reuse the development index first. See README_START_HERE.md.'
    exit 1
}
python experiment.py run --split dev --task open --preflight --out work/dev-preflight-v3
exit $LASTEXITCODE
