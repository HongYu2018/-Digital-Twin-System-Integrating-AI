# Version-3 semantic development evaluation

Exploratory conversational AI assessment; non-blinded and not independently expert validated. All 132 answers inspected; primary aggregation excludes the same source-conflicted question across all six configurations (21 questions per condition). Three generation failures retained with zero credit.

| Configuration | Correctness | Completeness | Fully correct and complete | Reasoning (11) | Failures |
|---|---:|---:|---:|---:|---:|
| LLM only | 0.071 | 0.048 | 0/21 | 0.045 | 0 |
| Vector RAG | 0.738 | 0.810 | 12/21 | 0.636 | 0 |
| Vector RAG + chunk KG | 0.786 | 0.810 | 12/21 | 0.636 | 0 |
| Vector RAG + chunk KG + static CLKM | 0.762 | 0.786 | 12/21 | 0.545 | 1 |
| Vector RAG + chunk KG + updated CLKM | 0.810 | 0.845 | 15/21 | 0.636 | 1 |
| Vector RAG + updated CLKM | 0.762 | 0.845 | 14/21 | 0.682 | 1 |

Indices are normalized rubric judgements, not precision/recall/F1 or independent truth estimates. Correctness includes material errors in optional content; completeness measures coverage of the required meanings. A complete but partly wrong answer can therefore have high completeness and lower correctness.

## Retrieval diagnostic

| Configuration | Chunks supplied | Selected reference-quote coverage | Median seconds (all 22 jobs) |
|---|---:|---:|---:|
| LLM only | 0–0 | N/A | 3.6 |
| Vector RAG | 5–5 | 0.667 | 9.9 |
| Vector RAG + chunk KG | 6–13 | 0.786 | 16.4 |
| Vector RAG + chunk KG + static CLKM | 6–13 | 0.786 | 14.6 |
| Vector RAG + chunk KG + updated CLKM | 6–13 | 0.786 | 13.7 |
| Vector RAG + updated CLKM | 5–5 | 0.667 | 10.6 |

Reference-quote coverage is a whitespace-normalized exact-span diagnostic, not exhaustive semantic recall. Four questions gain quoted evidence with graph expansion. Increased context size is part of this comparison; it is not a matched-token efficiency experiment.

## Comparison with version 2

| Configuration | V2 fully correct/complete | V3 fully correct/complete | V2 completeness | V3 completeness |
|---|---:|---:|---:|---:|
| LLM only | 0/21 | 0/21 | 0.048 | 0.048 |
| Vector RAG | 13/21 | 12/21 | 0.833 | 0.810 |
| Vector RAG + chunk KG | 11/21 | 12/21 | 0.798 | 0.810 |
| Vector RAG + chunk KG + static CLKM | 14/21 | 12/21 | 0.833 | 0.786 |
| Vector RAG + chunk KG + updated CLKM | 14/21 | 15/21 | 0.798 | 0.845 |
| Vector RAG + updated CLKM | 15/21 | 14/21 | 0.881 | 0.845 |

Version 3 changes retrieval, removes memory ranking bonuses, increases context and output allowances, and supplies more graph-linked evidence. Differences cannot be attributed solely to a single change. Same rubric, source-conflict exclusion and reasoning subset; subjective judgements remain uncertain.

## Findings and boundaries

- The initial five vector chunks are retained in every hybrid record, with added one-hop paths from the first three. Hybrid static and updated CLKM receive identical evidence; guidance no longer changes retrieval.
- Updated guidance improves the G-LMRC replacement/masking and initiating-cause answers compared with the corresponding static answers. This is a task-specific observation, not proof of a generally superior architecture.
- G-CIMU answers still mishandle rejected hypotheses and initiating causes. The critical rig-test rejection is not recovered by this retrieval run.
- Graph expansion adds useful evidence, but can also distract: initial touchdown answers import later crew-input attribution; the graph-only gear answer incorrectly adds left shock absorber replacement.
- On the possible shock-absorber contribution, all retrieval conditions strengthen possibility to likelihood in at least part of the answer.
- Three aaib-009-q02 responses (hybrid static, hybrid updated, vector updated) reached the 1,536-token output limit. No partial answer recovery or favourable exclusion was used.
- Existing CLKM is prepared guidance, not an implemented KG-to-memory learning process. No human-centred benefit or operational digital-twin validation is established.

## Paired completeness differences

| Contrast | Difference | Exploratory 95% interval |
|---|---:|---:|
| clkm_updated minus vector_rag | 0.036 | [-0.057, 0.136] |
| clkm_updated minus clkm_static | 0.060 | [0.000, 0.115] |
| clkm_updated minus vector_notes | 0.000 | [0.000, 0.000] |

Intervals use 2,000 resamples of five incident clusters (seed 17). They omit assessor uncertainty and are not adjusted for multiple comparisons. They are exploratory, not confirmatory superiority tests.

## What these scores do not cover

Semantic citation-support scores were not assigned in this v3 package. Cited chunks are exposed for inspection and ID/quotation checks are reported separately; those checks cannot establish entailment. Graph-edge semantic relevance has not been independently labelled. No held-out evaluation has been conducted.

Read METHODOLOGY.md and inspect ANSWER_REVIEW.html before using the numbers. Preserve this run rather than modifying outputs or selectively retrying unfavourable cases.
