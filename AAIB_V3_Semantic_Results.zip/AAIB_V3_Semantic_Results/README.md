# Version-3 semantic results

Read RESULTS.md for the tables and limitations. Open ANSWER_REVIEW.html for all 132 answers, scoring notes, source quotations and cited chunks. This is non-blinded conversational AI assessment, not independent expert validation or held-out testing.

Recompute the tables with Python 3.10+:

```powershell
python reproduce.py
```

No extra packages, Ollama or network calls are needed. This aggregates explicit saved judgements in assessments.py; it does not independently reproduce the semantic judgement process or automatically score new answers. METHODOLOGY.md defines scales, scope and borderline alternatives. semantic_assessments.jsonl contains answer-level scores. component_diagnostics.jsonl separates mechanical retrieval and runtime checks. results.json contains machine-readable tables. inputs/ preserves the uploaded raw snapshots and the earlier reference/summary files. No generated answers or original reference labels have been edited.

This reconstruction is new revision work; it is not recovered original experimental evidence. The static/updated memory is prepared guidance, not demonstrated KG-derived continual learning. Do not claim human benefit or universal architectural superiority from this development evaluation.
