# Assessment method and limitations

This is an AI assessment of the uploaded dev-open-v3-32k run, performed in the conversation on 23 September 2026. All 132 answer texts were read. The assessor used the reviewed reference passages, inspected the cited chunks and consulted additional report text for disputed interpretations. This was not a separately executed automated judge, independent expert assessment, blind assessment or replicated assessor study. Configuration identities were visible. The exact underlying conversational assessor build was not recorded; do not invent a model version in the manuscript.

## Data and denominators

22 development questions × 6 conditions, one generation each. All 132 records are unique. Three records (aaib-009-q02 in hybrid static, hybrid updated and vector updated CLKM) reached the 1,536-token output limit; all are retained with zero correctness, completeness and reasoning credit. One question (aaib-001-q03) is source-conflicted and excluded from primary aggregation for all six conditions. The primary sample is therefore 21 questions × 6 = 126 responses from five incident groups. All 132 remain in the downloadable review. The held-out test set is not evaluated here.

Question and source snapshots, generation settings and model digests are in inputs/. Reproduction code reads the frozen explicit judgements in assessments.py. It recomputes numbers but does not reproduce semantic judgement by calling a model. A reviewer can change an explicit judgement and rerun to inspect its impact.

## Scales

Correctness: 2 = a substantive source-supported answer without an identified material factual/attribution/qualification error; 1 = mixed supported content with an identified error/overstatement; 0 = materially wrong substantive answer or no substantive answer. Reported index is the average divided by two. A correct but incomplete answer can score 2 here; omissions are measured separately. Zero for non-answer avoids rewarding silence, but means this is a task-level correctness index, not a hallucination rate.

Completeness: each listed minimum meaning requirement receives 1 = adequately expressed, 0.5 = partial (e.g. correct component/relationship with incomplete qualification or missing essential detail), or 0 = absent/contradicted. Requirements are averaged within each answer, then over questions. These are semantic requirement units, not uniformly atomic fact counts. A concise response can receive full credit. It need not repeat the reference wording. Correct optional source-supported material does not increase or decrease completeness; incorrect extra material can reduce correctness.

Reasoning: 11 designated causal/temporal/uncertainty questions receive 2 = correct expressed reasoning or correctly scoped finding, 1 = incomplete/mixed reasoning, 0 = wrong reasoning or no relevant reasoning. This assesses visible content only, not internal reasoning. Other questions are not applicable and are excluded from this index, not scored zero. Designated keys are in assessments.py/REASON.

Citation support: no new semantic citation-support index is assigned in this v3 package. Cited chunks are exposed for inspection. Citation ID validity and verbatim evidence-quote checks are mechanical diagnostics and do not establish entailment.

These indices are not classical precision, recall or F1. A semantic P/R/F1 table would require a consistently atomized assertion inventory and explicit TP/FP/FN alignment. It would be misleading to rename these rubric indices as those metrics or infer confusion counts from them.

## Source and rubric corrections

G-OASB summary says two bounces; recorded data describes a second and third bounce. The previous reference review covered the selected reference passages and missed this discrepancy. The earlier diagnosis treating a three-bounce account as automatically incorrect was too strong. Primary exclusion is uniform across systems and is explicitly post hoc after discovering a source conflict. It does not erase other errors, such as importing the G-AYSH event into G-OASB or claiming the warning proves an improper landing configuration. The excluded answers are preserved.

For aaib-017-q01 the question asks whether the contactor was the cause. Correctly saying contributory, not causal, is sufficient. The earlier reference also required mechanical explanation, which is now optional under the same question-scope principle used in the earlier reference review. This amendment is uniform across systems. This same question-scope amendment was already used for version 1 and remains unchanged here. Labels must now be frozen before held-out evaluation, with any later source corrections logged and applied uniformly.

## Borderline assessments

Inspect partial-credit entries, especially modal strength (possible versus likely), a concise answer to a question already containing 'likely', attribution to pathology versus investigation, bearing-case attribution, and a contribution described as 'not sole cause' rather than 'not a cause'. A different qualified assessor may disagree. The downloadable original answers, cited passages and notes expose these judgements rather than hiding them behind a single score. No claim of inter-rater agreement is made.

## Component diagnostics

Known reference-quote coverage checks whitespace-normalized reference quotes in supplied passages. It is an exact source-span diagnostic only. It can miss semantically equivalent passages and is neither complete retrieval recall nor evidence completeness. Answer semantic scores never use this matching rule.

Graph diagnostics count emitted links and check endpoint presence and target-report association. They do not adjudicate the semantic utility of every edge, entailment of extracted triples, or causal validity. Those independent graph-relevance labels are not yet available. The results explicitly avoid presenting these counts as edge precision.

CLKM: current prepared guidance provenance is preserved. The uploaded run verifies identical retrieved evidence for the three hybrid conditions, identical vector evidence with/without updated CLKM, and matched updated guidance in the vector and hybrid conditions. No new independent memory-applicability labels or KG-to-memory learning validation are claimed.

## Uncertainty and reporting

Exploratory completeness differences use 2,000 bootstrap resamples of the five incident groups, seed 17. They preserve within-group question dependence but do not model annotation uncertainty; five groups is a very small sample. Intervals are not multiplicity-adjusted and do not establish superiority.

For the journal revision, report this as development diagnosis and freeze a defensible semantic protocol before test evaluation. A stratified independent expert audit of reference/answer judgements, including partial-credit, truncated-response and source-conflict cases, would assess assessor reliability without requiring one person to score every output. No human-centred usability or operational digital-twin benefit is measured here.

## Version-3 handling and comparability

The same 21 primary questions, 11 reasoning questions and question-scope amendment apply as before. No new questions were excluded. The generation prompt, raw output and failed records are retained. Evidence-check arrays are not counted as answer text; only completed answer fields receive semantic scores. No partial output-limit response was salvaged.

Correctness/completeness are separate: a correct post-flight detection answer without the cover-wear detail is incomplete but not necessarily false. A complete required answer with unsupported extra actor attribution can be complete but receive correctness 1. The initial removal hypothesis can be named while the required rig-test rejection is answered incorrectly; those two units are scored separately. Missing retrieval is an explanation for a failure, not an exemption from scoring the answer against the source.

## Judgement sensitivity

Two especially interpretive decisions can affect small rankings:

- aaib-017-u01, vector RAG: the primary judgement follows the prior cautious treatment of a correct opening weakened by later “not ... sole initiating cause” language (correctness 1, completeness 0.5, reasoning 1). A reader who treats the later wording as compatible with the explicit opening could score 2, 1, 2. This would add 1/42 to its correctness index, 0.5/21 to completeness, 1/22 to reasoning and one fully correct/complete answer.
- aaib-017-u01, hybrid updated CLKM: the primary judgement accepts the central non-causal/contributory distinction and treats “complexity ... and lack of recurrence” as a broad interpretation of the investigation difficulty. The report explicitly says the incident fault could not be replicated (c0019), but does not explicitly identify “complexity” as the reason. A stricter assessor could reduce correctness from 2 to 1 for that additional explanation. Required-meaning coverage remains 1; the fully correct/complete count then falls from 15 to 14 and correctness from 0.810 to 0.786.

These are disclosed alternatives, not changes made to force a desired ranking. They illustrate why a one-answer advantage needs independent calibration and cannot establish superiority. Other possible disagreements include modal strength and optional-detail attribution. Source and answer texts permit a reviewer to inspect every decision. No inter-rater reliability is claimed.
